/* الواجهة: عرض + أحداث بالتفويض (data-act) */
(function () {
  const E = globalThis.EDT, M = E.model, S = E.solver, esc = E.esc;
  const KEY = "edt-dz-v2";
  const app = (E.app = { st: null, ui: { tab: "school", view: "class", sel: { class: null, teacher: null } }, modal: null });

  /* ---------- حفظ/تحميل ---------- */
  function load() {
    try {
      const o = JSON.parse(localStorage.getItem(KEY) || "null");
      if (o && o.st && o.st.school && Array.isArray(o.st.assignments)) { app.st = o.st; Object.assign(app.ui, o.ui || {}); }
    } catch (e) { /* تجاهل */ }
    if (!app.st) app.st = M.blank("secondary");
  }
  let saveTimer;
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { try { localStorage.setItem(KEY, JSON.stringify({ st: app.st, ui: app.ui })); } catch (e) { /* ممتلئ */ } }, 150);
  }
  let toastTimer;
  function toast(msg, kind) {
    const t = document.getElementById("toast");
    t.textContent = msg; t.className = "toast show " + (kind || "");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.className = "toast"), 3200);
  }
  const commit = () => { M.reconcile(app.st); save(); render(); };
  const $ = (id) => document.getElementById(id);

  /* ---------- عناصر مساعدة ---------- */
  const TABS = [["school", "المؤسسة"], ["classes", "الأقسام"], ["subjects", "المواد"], ["teachers", "الأساتذة"], ["assign", "الإسناد"], ["board", "الجداول"]];
  const PREFER = { any: "حرة", morning: "تفضّل صباحًا", afternoon: "تفضّل مساءً" };
  const field = (label, html) => `<label class="fld"><span>${label}</span>${html}</label>`;
  const inputText = (k, v, ph) => `<input type="text" data-act="schoolField" data-k="${k}" value="${esc(v)}" placeholder="${esc(ph || "")}">`;
  const sName = (id) => (M.subjectOf(app.st, id) || { name: "؟" }).name;
  function asgTitle(a) {
    if (a.parts.length === 1) { const p = a.parts[0]; return sName(p.subjectId) + (p.label ? ` (${p.label})` : ""); }
    return a.parts.map((p) => p.label || sName(p.subjectId)).join(" / ");
  }
  const classChips = (a) => a.classIds.map((c) => `<span class="chip">${esc(M.className(app.st, c))}</span>`).join("");
  function teacherOptions(subjectId, selected) {
    const mine = app.st.teachers.filter((t) => t.subjectIds.includes(subjectId));
    const others = app.st.teachers.filter((t) => !t.subjectIds.includes(subjectId));
    const opt = (t) => `<option value="${t.id}" ${t.id === selected ? "selected" : ""}>${esc(t.name)}</option>`;
    return `<option value="">— اختر أستاذًا —</option>` + (mine.length ? `<optgroup label="أساتذة المادة">${mine.map(opt).join("")}</optgroup>` : "") + (others.length ? `<optgroup label="أساتذة آخرون">${others.map(opt).join("")}</optgroup>` : "");
  }
  const subjectOptions = (sel) => app.st.subjects.map((s) => `<option value="${s.id}" ${s.id === sel ? "selected" : ""}>${esc(s.name)}</option>`).join("");

  /* ================= التبويبات ================= */
  function tabSchool() {
    const st = app.st, sc = st.school;
    return `
    <section class="card"><h2>بيانات المؤسسة</h2><div class="grid2">
      ${field("اسم المؤسسة", inputText("name", sc.name))}${field("السنة الدراسية", inputText("year", sc.year))}
      ${field("الولاية", inputText("wilaya", sc.wilaya))}${field("البلدية", inputText("commune", sc.commune))}
      ${field("مدير المؤسسة", inputText("director", sc.director))}${field("مستشار التوجيه", inputText("counselor", sc.counselor))}
      ${field("الهاتف", inputText("phone", sc.phone))}
    </div>
    <label class="sw"><input type="checkbox" data-act="schoolToggle" data-k="thursdayMorningOnly" ${sc.thursdayMorningOnly ? "checked" : ""}> الخميس صباحًا فقط</label>
    <label class="sw"><input type="checkbox" data-act="schoolToggle" data-k="amazigh" ${sc.amazigh ? "checked" : ""}> تدريس اللغة الأمازيغية (يُضاف لكل الأقسام)</label>
    </section>
    <section class="card"><h2>الطور: ${E.CYCLE_LABEL[sc.cycle]}</h2>
      <p class="muted">تغيير الطور يبدأ مشروعًا جديدًا فارغًا.</p>
      <div class="row">${["primary", "middle", "secondary"].map((c) => `<button class="btn ${c === sc.cycle ? "" : "ghost"}" data-act="newProject" data-cycle="${c}">${E.CYCLE_LABEL[c]}</button>`).join("")}</div>
    </section>
    <section class="card"><h2>نماذج جاهزة للتجربة</h2>
      <p class="muted">كل نموذج يُحمَّل ويُولَّد جدوله مباشرة.</p>
      <div class="row">
        <button class="btn" data-act="demo" data-d="secondaryTech">ثانوي تقني (دمج + تخصصات + تطبيقات)</button>
        <button class="btn ghost" data-act="demo" data-d="middle">متوسط</button>
        <button class="btn ghost" data-act="demo" data-d="primary">ابتدائي</button>
      </div></section>
    <section class="card"><h2>نسخة احتياطية</h2><div class="row">
      <button class="btn ghost" data-act="exportJson">حفظ نسخة (JSON)</button>
      <button class="btn ghost" data-act="importPick">استيراد نسخة</button>
      <input id="importFile" type="file" accept=".json,application/json" hidden>
      <button class="btn danger" data-act="resetAll">مسح كل البيانات</button></div></section>`;
  }

  function tabClasses() {
    const st = app.st, levels = E.levelsFor(st.school.cycle);
    const groups = new Map();
    for (const c of st.classes) { if (!groups.has(c.label)) groups.set(c.label, []); groups.get(c.label).push(c); }
    const hours = (c) => M.sum(st.assignments.filter((a) => a.classIds.includes(c.id)).map((a) => a.periods));
    return `
    <section class="card"><h2>إضافة أقسام</h2>
      <div class="grid2">${field("المستوى", `<select id="lvl">${levels.map((l) => `<option value="${l.key}">${esc(l.label)}</option>`).join("")}</select>`)}
      ${field("عدد الأفواج التربوية الجديدة", `<input id="cnt" type="number" min="1" max="12" value="1">`)}</div>
      <button class="btn" data-act="addClass">إضافة</button></section>
    <section class="card"><div class="row between"><h2>الأقسام (${st.classes.length})</h2>
      <button class="btn ghost" data-act="openMerge" ${st.classes.length < 2 ? "disabled" : ""}>دمج أقسام / تخصصات</button></div>
      ${st.classes.length ? "" : `<p class="muted">لا توجد أقسام بعد.</p>`}
      ${[...groups].map(([label, list]) => `<h3>${esc(label)}</h3><div class="list">${list.map((c) => `<div class="item"><b>${esc(c.name)}</b><span class="muted">${hours(c)} ساعة/أسبوع</span><button class="icon danger" data-act="delClass" data-id="${c.id}" aria-label="حذف">🗑</button></div>`).join("")}</div>`).join("")}
    </section>`;
  }

  function tabSubjects() {
    const st = app.st;
    const used = (id) => st.assignments.some((a) => a.parts.some((p) => p.subjectId === id));
    return `
    <section class="card"><h2>المواد</h2>
      <p class="muted">«صباحًا فقط» قيد صارم: لا تُوضع المادة بعد الظهر أبدًا (للمواد العلمية). «التفضيل» اختياري ويُراعى قدر الإمكان.</p>
      <div class="list">${st.subjects.map((s) => `<div class="item col">
        <div class="row between"><b>${esc(s.name)}</b><span class="chip">${esc(s.short)}</span></div>
        <div class="row">
          <label class="sw"><input type="checkbox" data-act="subjSci" data-id="${s.id}" ${s.sci ? "checked" : ""}> صباحًا فقط</label>
          <select data-act="subjPrefer" data-id="${s.id}">${Object.entries(PREFER).map(([k, v]) => `<option value="${k}" ${s.prefer === k ? "selected" : ""}>${v}</option>`).join("")}</select>
          ${used(s.id) ? "" : `<button class="icon danger" data-act="subjDel" data-id="${s.id}">🗑</button>`}
        </div></div>`).join("") || `<p class="muted">تُضاف المواد تلقائيًا مع الأقسام.</p>`}</div></section>
    <section class="card"><h2>مادة جديدة</h2><div class="grid2">
      ${field("الاسم", `<input id="newSubName" type="text">`)}${field("الاختصار", `<input id="newSubShort" type="text" maxlength="4">`)}</div>
      <button class="btn" data-act="subjAdd">إضافة مادة</button></section>`;
  }

  function tabTeachers() {
    const st = app.st;
    return `
    <section class="card"><div class="row between"><h2>الأساتذة (${st.teachers.length})</h2><button class="btn" data-act="teacherNew">+ أستاذ</button></div>
      ${st.teachers.length ? "" : `<p class="muted">أضف الأساتذة ثم أسند لهم الحصص من تبويب «الإسناد».</p>`}
      <div class="list">${st.teachers.map((t) => {
        const load = M.teacherLoad(st, t.id);
        return `<div class="item col"><div class="row between"><b>${esc(t.name)}</b><span class="chip ${load > t.maxPeriods ? "bad" : ""}">${load} / ${t.maxPeriods} س</span></div>
          <div class="muted">${t.subjectIds.map(sName).map(esc).join("، ") || "—"}${t.unavailable.length ? ` · ${t.unavailable.length} فترة غير متاحة` : ""}</div>
          <div class="row"><button class="btn ghost sm" data-act="teacherEdit" data-id="${t.id}">تعديل</button><button class="btn ghost sm" data-act="availOpen" data-id="${t.id}">أوقات عدم التوفر</button><button class="btn danger sm" data-act="teacherDel" data-id="${t.id}">حذف</button></div></div>`;
      }).join("")}</div></section>`;
  }

  function tabAssign() {
    const st = app.st;
    const filter = app.ui.asgFilter || "";
    const rows = (list) => list.map((a) => `
      <div class="item col asg ${a.parts.some((p) => !p.teacherId) ? "warn" : ""}">
        <div class="row between"><b>${esc(asgTitle(a))}</b><span>${classChips(a)}</span></div>
        ${a.parts.map((p, i) => `<div class="row part">${a.parts.length > 1 ? `<span class="chip">${esc(p.label || sName(p.subjectId))}</span>` : ""}
          <select data-act="asgTeacher" data-aid="${a.id}" data-pi="${i}">${teacherOptions(p.subjectId, p.teacherId)}</select>
          ${a.parts.length === 1 && p.teacherId ? `<button class="btn ghost sm" data-act="asgToAll" data-aid="${a.id}" title="نفس الأستاذ لكل أقسام هذه المادة">للكل</button>` : ""}</div>`).join("")}
        <div class="row"><span class="muted">${a.periods} س · التقسيم</span>
          <input class="pat" type="text" inputmode="numeric" value="${M.patternStr(a.pattern)}" data-act="asgPattern" data-aid="${a.id}" aria-label="نمط التقسيم">
          ${a.morning === true ? `<span class="chip">صباحًا</span>` : ""}<span class="grow"></span>
          <button class="btn ghost sm" data-act="asgEdit" data-aid="${a.id}">تعديل</button><button class="icon danger" data-act="asgDel" data-aid="${a.id}">🗑</button></div>
      </div>`).join("");
    const single = st.assignments.filter((a) => a.classIds.length === 1 && a.parts.length === 1);
    const special = st.assignments.filter((a) => a.classIds.length > 1 || a.parts.length > 1);
    const byClass = st.classes.filter((c) => !filter || filter === c.id).map((c) => {
      const mine = single.filter((a) => a.classIds[0] === c.id);
      const sp = special.filter((a) => (filter ? a.classIds.includes(c.id) : a.classIds[0] === c.id));
      return mine.length || sp.length ? `<h3>${esc(c.name)}</h3>${rows(sp)}${rows(mine)}` : "";
    }).join("");
    return `
    <section class="card"><div class="row between"><h2>الإسناد</h2><button class="btn" data-act="asgNew">+ إسناد جديد</button></div>
      <p class="muted">لكل مادة: الأستاذ ونمط التقسيم (مثال: <b>2+2+1</b>). الحصص المدمجة والتطبيقات والتخصصات تظهر أولًا تحت القسم.</p>
      <label class="fld"><span>تصفية بالقسم</span><select data-act="asgFilter"><option value="">كل الأقسام</option>${st.classes.map((c) => `<option value="${c.id}" ${filter === c.id ? "selected" : ""}>${esc(c.name)}</option>`).join("")}</select></label>
    </section>${byClass || `<section class="card"><p class="muted">لا توجد إسنادات. أضف أقسامًا أولًا.</p></section>`}`;
  }

  /* ---------- الجداول ---------- */
  function currentSel() {
    const st = app.st, v = app.ui.view;
    const list = v === "class" ? st.classes : st.teachers;
    let id = app.ui.sel[v];
    if (!list.some((x) => x.id === id)) id = list[0] ? list[0].id : null;
    app.ui.sel[v] = id;
    return id;
  }
  function gridHtml(grid, kind, teacher) {
    const head = `<tr><th>الحصة</th>${grid.days.map((d) => `<th>${d}</th>`).join("")}</tr>`;
    const body = grid.rows.map((r, ri) => {
      if (r.kind === "break") return `<tr class="brkrow"><th>${esc(r.label)}</th>${grid.days.map((_, di) => { const c = grid.cells[ri][di]; return c && c.skip ? "" : `<td class="brk"></td>`; }).join("")}</tr>`;
      return `<tr><th>${esc(r.label)}<small>${r.time}</small></th>${grid.days.map((_, di) => {
        const c = grid.cells[ri][di];
        if (c && c.skip) return "";
        if (c && c.lines) return `<td class="cellp" rowspan="${c.rowspan}" style="background:${c.color}" data-act="cell" data-id="${esc(c.id)}">${c.lines.map((l, i) => (i === 0 ? `<b>${esc(l)}</b>` : `<span>${esc(l)}</span>`)).join("")}</td>`;
        const un = teacher && teacher.unavailable.includes(`${di}-${r.index}`);
        return `<td class="empty ${un ? "unav" : ""}" data-act="emptyCell" data-day="${di}" data-period="${r.index}">${un ? "✕" : "+"}</td>`;
      }).join("")}</tr>`;
    }).join("");
    return `<div class="tt-wrap"><table class="tt"><thead>${head}</thead><tbody>${body}</tbody></table></div>`;
  }
  function tabBoard() {
    const st = app.st, v = app.ui.view, id = currentSel();
    const { blocks } = M.toBlocks(st);
    const unplaced = M.unplacedBlocks(st);
    const diag = M.diagnostics(st);
    const stale = st.placements.length && st.genKey !== M.fingerprint(st);
    const list = v === "class" ? st.classes : st.teachers;
    const grid = id ? M.buildGrid(st, v, id) : null;
    const teacher = v === "teacher" ? st.teachers.find((t) => t.id === id) : null;
    const errors = diag.filter((d) => d.level === "error").length;
    return `
    <section class="card no-print"><div class="row">
      <button class="btn big" data-act="generate" id="genBtn">${st.placements.length ? "إعادة التوليد (نتيجة أخرى)" : "توليد الجدول"}</button></div>
      <div class="stats">
        <span class="chip ${unplaced.length ? "bad" : "good"}">موضوعة ${blocks.length - unplaced.length}/${blocks.length}</span>
        ${st.stats ? `<span class="chip">ثغرات الأقسام ${st.stats.classGaps}</span><span class="chip">ثغرات الأساتذة ${st.stats.teacherGaps}</span>` : ""}
        ${stale ? `<span class="chip bad">تغيّرت البيانات — أعد التوليد</span>` : ""}</div>
      ${diag.length ? `<details ${errors ? "open" : ""}><summary>${errors ? `⚠ ${errors} خطأ` : "ملاحظات"} (${diag.length})</summary><ul class="diag">${diag.map((d) => `<li class="${d.level}">${esc(d.text)}</li>`).join("")}</ul></details>` : ""}
      ${unplaced.length ? `<details><summary>حصص لم توضع (${unplaced.length}) — اضغط خانة فارغة لوضعها يدويًا</summary><ul class="diag">${unplaced.map((b) => { const a = st.assignments.find((x) => x.id === b.aid); return `<li class="warn">${esc(asgTitle(a))} — ${b.classIds.map((c) => esc(M.className(st, c))).join(" + ")} — ${b.length} س</li>`; }).join("")}</ul></details>` : ""}
    </section>
    <section class="card"><div class="row no-print">
      <div class="seg"><button class="${v === "class" ? "on" : ""}" data-act="setView" data-v="class">الأقسام</button><button class="${v === "teacher" ? "on" : ""}" data-act="setView" data-v="teacher">الأساتذة</button></div>
      <select data-act="setSel" class="grow">${list.map((x) => `<option value="${x.id}" ${x.id === id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></div>
      ${grid ? `<h3 class="tt-title">${esc(grid.title)} <small>(${grid.hours} س)</small></h3>${gridHtml(grid, v, teacher)}` : `<p class="muted">لا يوجد ${v === "class" ? "قسم" : "أستاذ"} لعرضه.</p>`}
    </section>
    <section class="card no-print"><h2>التصدير</h2><div class="row wrap">
      <button class="btn" data-act="exportPdf" data-scope="one" ${grid ? "" : "disabled"}>PDF — الجدول المعروض</button>
      <button class="btn ghost" data-act="exportPdf" data-scope="classes">PDF — كل الأقسام</button>
      <button class="btn ghost" data-act="exportPdf" data-scope="teachers">PDF — كل الأساتذة</button>
      <button class="btn ghost" data-act="exportXlsx">Excel — كل الجداول</button>
      <button class="btn ghost" data-act="printNow">طباعة</button></div></section>`;
  }

  /* ================= النوافذ ================= */
  function modalShell(title, body, foot) {
    return `<div class="backdrop" data-act="closeModal"></div><div class="sheet" role="dialog"><div class="sheet-h"><h2>${title}</h2><button class="icon" data-act="closeModal" aria-label="إغلاق">✕</button></div><div class="sheet-b">${body}</div>${foot ? `<div class="sheet-f">${foot}</div>` : ""}</div>`;
  }
  function renderModal() {
    const m = app.modal, host = $("modal");
    if (!m) { host.innerHTML = ""; host.className = ""; return; }
    host.className = "open";
    const st = app.st;
    let html = "";
    if (m.type === "asg") html = asgModal(m);
    else if (m.type === "merge") html = mergeModal(m);
    else if (m.type === "teacher") html = teacherModal(m);
    else if (m.type === "avail") html = availModal(m);
    else if (m.type === "cell") {
      const pl = st.placements.find((p) => p.id === m.id), g = M.buildGrid(st, app.ui.view, currentSel());
      let lines = [];
      for (const row of g.cells) for (const c of row) if (c && c.id === m.id) lines = c.lines;
      const grid = E.gridFor(st.school.cycle);
      const a = pl && grid.periods[pl.period], b = pl && grid.periods[pl.period + pl.length - 1];
      html = modalShell("تفاصيل الحصة", `<p><b>${lines.map(esc).join("<br>")}</b></p>${pl ? `<p class="muted">${E.DAYS[pl.day]} · ${a.start} → ${b.end} (${pl.length} س)</p>` : ""}`, `<button class="btn danger" data-act="unplace" data-id="${esc(m.id)}">إزالة من الجدول</button><button class="btn ghost" data-act="closeModal">إغلاق</button>`);
    } else if (m.type === "place") {
      const inp = M.solveInput(st, 1);
      const view = app.ui.view, id = currentSel();
      const cands = M.unplacedBlocks(st).filter((b) => (view === "class" ? b.classIds.includes(id) : b.teacherIds.includes(id)) && S.canPlace(inp, st.placements, b.id, m.day, m.period));
      html = modalShell(`وضع حصة — ${E.DAYS[m.day]} ${E.gridFor(st.school.cycle).periods[m.period].start}`,
        cands.length ? `<div class="list">${cands.map((b) => { const a = st.assignments.find((x) => x.id === b.aid); return `<button class="item btnlike" data-act="placeManual" data-bid="${esc(b.id)}"><b>${esc(asgTitle(a))}</b><span class="muted">${b.classIds.map((c) => esc(M.className(st, c))).join(" + ")} · ${b.length} س</span></button>`; }).join("")}</div>` : `<p class="muted">لا توجد حصة غير موضوعة تناسب هذا الموضع (تعارض أو قيد).</p>`);
    }
    host.innerHTML = html;
  }

  /* --- محرر الإسناد --- */
  const TYPES = { normal: "عادي", tp: "تطبيقات (أفواج)", merged: "قسم مدمج", spec: "تخصصات" };
  function asgModal(m) {
    const d = m.draft, st = app.st;
    const fieldsPart = d.parts.map((p, i) => `<div class="part-ed">
      <div class="grid2">${field("المادة", `<select data-act="draftPart" data-i="${i}" data-f="subjectId">${subjectOptions(p.subjectId)}</select>`)}
      ${field("اسم الفوج/التخصص (اختياري)", `<input type="text" data-act="draftPart" data-i="${i}" data-f="label" value="${esc(p.label)}">`)}</div>
      ${field("الأستاذ", `<select data-act="draftPart" data-i="${i}" data-f="teacherId">${teacherOptions(p.subjectId, p.teacherId)}</select>`)}
      ${d.parts.length > 1 ? `<button class="btn danger sm" data-act="draftDelPart" data-i="${i}">حذف الجزء</button>` : ""}</div>`).join("");
    const body = `
      <div class="row wrap">${Object.entries(TYPES).map(([k, v]) => `<button class="btn ${d.type === k ? "" : "ghost"} sm" data-act="draftType" data-t="${k}">${v}</button>`).join("")}</div>
      <p class="muted">${{ normal: "قسم واحد، مادة واحدة، أستاذ واحد.", tp: "الأفواج تدرس في الحصة نفسها (مثل علوم/فيزياء أو عربية/إعلام آلي): أستاذان متزامنان.", merged: "عدة أقسام تدرس معًا مادة واحدة بأستاذ واحد.", spec: "أقسام مدمجة تتفرع إلى أفواج متزامنة، لكل فوج مادته وأستاذه." }[d.type]}</p>
      <h3>الأقسام</h3><div class="checks">${st.classes.map((c) => `<label class="sw"><input type="checkbox" data-act="draftClass" data-id="${c.id}" ${d.classIds.includes(c.id) ? "checked" : ""}> ${esc(c.name)}</label>`).join("")}</div>
      <h3>الأجزاء المتزامنة</h3>${fieldsPart}
      ${d.type === "tp" || d.type === "spec" ? `<button class="btn ghost sm" data-act="draftAddPart">+ جزء (فوج)</button>` : ""}
      <h3>الحصص</h3><div class="grid2">
        ${field("الساعات الأسبوعية", `<input type="number" min="1" max="20" data-act="draftField" data-f="periods" value="${d.periods}">`)}
        ${field("نمط التقسيم (مثال 2+2+1 أو 4)", `<input type="text" data-act="draftField" data-f="pattern" value="${esc(d.pattern)}">`)}</div>
      <div class="grid2">${field("وقت الحصة", `<select data-act="draftField" data-f="morning"><option value="auto" ${d.morning === "auto" ? "selected" : ""}>حسب المادة</option><option value="yes" ${d.morning === "yes" ? "selected" : ""}>صباحًا فقط</option><option value="no" ${d.morning === "no" ? "selected" : ""}>حرة</option></select>`)}</div>
      <label class="sw"><input type="checkbox" data-act="draftField" data-f="cross" ${d.cross ? "checked" : ""}> السماح بعبور الاستراحة القصيرة (تلقائي لكتل 3 ساعات فأكثر، فتتسع الكتلة 4 ساعات صباحًا)</label>`;
    return modalShell(m.editId ? "تعديل الإسناد" : "إسناد جديد", body, `<button class="btn" data-act="asgSave">حفظ</button><button class="btn ghost" data-act="closeModal">إلغاء</button>`);
  }
  function draftFrom(a) {
    return { type: a.parts.length > 1 ? (a.classIds.length > 1 ? "spec" : "tp") : a.classIds.length > 1 ? "merged" : "normal", classIds: a.classIds.slice(), parts: E.clone(a.parts), periods: a.periods, pattern: M.patternStr(a.pattern), morning: a.morning === true ? "yes" : a.morning === false ? "no" : "auto", cross: !!a.crossBreak };
  }
  function newDraft() {
    const st = app.st;
    return { type: "normal", classIds: st.classes[0] ? [st.classes[0].id] : [], parts: [{ subjectId: (st.subjects[0] || {}).id || "", teacherId: null, label: "" }], periods: 2, pattern: "2", morning: "auto", cross: false };
  }

  /* --- أداة الدمج --- */
  function mergeCommon(m) {
    const st = app.st;
    if (m.classIds.length < 2) return [];
    const sets = m.classIds.map((cid) => new Set(st.assignments.filter((a) => a.classIds.length === 1 && a.classIds[0] === cid && a.parts.length === 1).map((a) => a.parts[0].subjectId)));
    return st.subjects.filter((s) => sets.every((x) => x.has(s.id)));
  }
  function mergeModal(m) {
    const st = app.st, common = mergeCommon(m);
    const body = `
      <p class="muted">اختر الأقسام التي تدرس معًا (مثل: ثانية وثالثة تقني رياضي). ثم حدّد المواد المشتركة، وإن وُجدت مادة تتفرع إلى تخصصات فاختَرها وأدخل أسماء الأفواج.</p>
      <h3>الأقسام المدمجة</h3><div class="checks">${st.classes.map((c) => `<label class="sw"><input type="checkbox" data-act="mergeClass" data-id="${c.id}" ${m.classIds.includes(c.id) ? "checked" : ""}> ${esc(c.name)}</label>`).join("")}</div>
      ${m.classIds.length < 2 ? `<p class="muted">اختر قسمين على الأقل.</p>` : `
      <h3>المواد المشتركة (إسناد واحد لكل المدمجين)</h3>
      <div class="checks">${common.map((s) => `<label class="sw"><input type="checkbox" data-act="mergeSub" data-id="${s.id}" ${m.common.includes(s.id) ? "checked" : ""}> ${esc(s.name)}</label>`).join("") || `<span class="muted">لا توجد مواد مشتركة بين الأقسام المختارة.</span>`}</div>
      <h3>مادة التخصص (اختياري)</h3>
      ${field("المادة التي تتفرع إلى أفواج", `<select data-act="mergeSpec"><option value="">— لا شيء —</option>${common.map((s) => `<option value="${s.id}" ${m.spec === s.id ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select>`)}
      ${m.spec ? field("أسماء الأفواج (سطر لكل فوج)", `<textarea rows="4" data-act="mergeGroups">${esc(m.groups)}</textarea>`) : ""}`}`;
    return modalShell("دمج أقسام وتخصصات", body, `<button class="btn" data-act="mergeDo" ${m.classIds.length < 2 ? "disabled" : ""}>تنفيذ الدمج</button><button class="btn ghost" data-act="closeModal">إلغاء</button>`);
  }

  /* --- الأساتذة --- */
  function teacherModal(m) {
    const d = m.draft;
    return modalShell(m.editId ? "تعديل الأستاذ" : "أستاذ جديد",
      `${field("الاسم", `<input type="text" data-act="tDraft" data-f="name" value="${esc(d.name)}">`)}
       ${field("النصاب الأسبوعي (ساعات)", `<input type="number" min="1" max="40" data-act="tDraft" data-f="maxPeriods" value="${d.maxPeriods}">`)}
       <h3>المواد التي يدرّسها</h3><div class="checks">${app.st.subjects.map((s) => `<label class="sw"><input type="checkbox" data-act="tSub" data-id="${s.id}" ${d.subjectIds.includes(s.id) ? "checked" : ""}> ${esc(s.name)}</label>`).join("") || `<span class="muted">أضف أقسامًا أولًا لتظهر المواد.</span>`}</div>`,
      `<button class="btn" data-act="teacherSave">حفظ</button><button class="btn ghost" data-act="closeModal">إلغاء</button>`);
  }
  function availModal(m) {
    const st = app.st, t = st.teachers.find((x) => x.id === m.id), grid = E.gridFor(st.school.cycle);
    if (!t) return "";
    return modalShell(`عدم التوفر: ${esc(t.name)}`,
      `<p class="muted">اضغط الخانات التي لا يمكن للأستاذ التدريس فيها.</p><div class="tt-wrap"><table class="tt avail"><thead><tr><th></th>${E.DAYS.map((d) => `<th>${d}</th>`).join("")}</tr></thead><tbody>${grid.periods.map((p) => `<tr><th>${p.label}<small>${p.start}</small></th>${E.DAYS.map((_, di) => { const on = t.unavailable.includes(`${di}-${p.index}`); return `<td class="${on ? "unav" : "empty"}" data-act="availToggle" data-d="${di}" data-p="${p.index}">${on ? "✕" : ""}</td>`; }).join("")}</tr>`).join("")}</tbody></table></div>`,
      `<button class="btn ghost" data-act="availClear">مسح الكل</button><button class="btn" data-act="closeModal">تم</button>`);
  }

  /* ================= العرض ================= */
  function render() {
    const y = window.scrollY;
    const st = app.st, tab = app.ui.tab;
    $("hdrName").textContent = st.school.name || "مؤسسة جديدة";
    $("hdrYear").textContent = `${E.CYCLE_LABEL[st.school.cycle]} · ${st.school.year}`;
    $("tabs").innerHTML = TABS.map(([id, label]) => `<button class="${tab === id ? "on" : ""}" data-act="tab" data-tab="${id}">${label}</button>`).join("");
    const views = { school: tabSchool, classes: tabClasses, subjects: tabSubjects, teachers: tabTeachers, assign: tabAssign, board: tabBoard };
    $("view").innerHTML = views[tab]();
    renderModal();
    window.scrollTo(0, y);
  }
  E.render = render;

  /* ================= الأحداث ================= */
  const A = {};
  const confirmBox = (msg) => globalThis.confirm(msg);

  A.tab = (el) => { app.ui.tab = el.dataset.tab; save(); render(); window.scrollTo(0, 0); };
  A.closeModal = () => { app.modal = null; renderModal(); };
  A.schoolField = (el) => { app.st.school[el.dataset.k] = el.value; save(); $("hdrName").textContent = app.st.school.name || "مؤسسة جديدة"; };
  A.schoolToggle = (el) => {
    const k = el.dataset.k;
    if (k === "amazigh") M.setAmazigh(app.st, el.checked); else app.st.school[k] = el.checked;
    commit();
  };
  A.newProject = (el) => {
    if (el.dataset.cycle === app.st.school.cycle && !app.st.classes.length) return;
    if (!confirmBox("سيبدأ مشروع جديد فارغ وتُمحى البيانات الحالية. المتابعة؟")) return;
    const old = app.st.school, st = M.blank(el.dataset.cycle);
    Object.assign(st.school, { wilaya: old.wilaya, commune: old.commune, year: old.year, director: old.director, counselor: old.counselor, phone: old.phone });
    app.st = st; app.ui.tab = "classes"; commit();
  };
  function generate() {
    const st = app.st;
    st.seed = (st.seed || 0) + 1;
    const inp = M.solveInput(st, st.seed);
    const r = S.solve(inp);
    st.placements = r.placements; st.stats = { classGaps: r.classGaps, teacherGaps: r.teacherGaps }; st.genKey = M.fingerprint(st);
    return r;
  }
  A.demo = (el) => {
    if (app.st.classes.length && !confirmBox("سيُستبدل المشروع الحالي بالنموذج. المتابعة؟")) return;
    app.st = E.demos[el.dataset.d](); app.ui.sel = { class: null, teacher: null }; app.ui.tab = "board"; app.ui.view = "class";
    generate(); commit(); toast("تم تحميل النموذج وتوليد الجدول", "ok");
  };
  A.exportJson = () => E.exp.save(`emploi-${(app.st.school.name || "backup").replace(/\s+/g, "_")}.json`, new Blob([JSON.stringify(app.st)], { type: "application/json" }));
  A.importPick = () => $("importFile").click();
  A.resetAll = () => { if (confirmBox("مسح كل البيانات نهائيًا؟")) { app.st = M.blank(app.st.school.cycle); commit(); } };

  A.addClass = () => {
    const key = $("lvl").value, n = Math.max(1, Math.min(12, parseInt($("cnt").value, 10) || 1));
    let added = 0, section = 1;
    while (added < n && section < 60) { if (M.addClass(app.st, key, section)) added++; section++; }
    commit(); toast(`أُضيف ${added} قسم`, "ok");
  };
  A.delClass = (el) => { if (confirmBox("حذف القسم وإسناداته؟")) { M.removeClass(app.st, el.dataset.id); commit(); } };
  A.openMerge = () => { app.modal = { type: "merge", classIds: [], common: [], spec: "", groups: E.DEFAULT_SPEC_GROUPS.join("\n") }; renderModal(); };
  A.mergeClass = (el) => {
    const m = app.modal, id = el.dataset.id;
    m.classIds = el.checked ? [...m.classIds, id] : m.classIds.filter((x) => x !== id);
    const ids = mergeCommon(m).map((x) => x.id);
    m.spec = ids.includes("engi") ? "engi" : "";
    m.common = ids.filter((x) => x !== m.spec); renderModal();
  };
  A.mergeSub = (el) => { const m = app.modal, id = el.dataset.id; m.common = el.checked ? [...m.common, id] : m.common.filter((x) => x !== id); if (el.checked && m.spec === id) m.spec = ""; renderModal(); };
  A.mergeSpec = (el) => { const m = app.modal; m.spec = el.value; m.common = m.common.filter((x) => x !== m.spec); renderModal(); };
  A.mergeGroups = (el) => { app.modal.groups = el.value; };
  A.mergeDo = () => {
    const m = app.modal, groups = m.groups.split(/\n+/).map((x) => x.trim()).filter(Boolean);
    if (m.spec && groups.length < 2) { toast("أدخل فوجين على الأقل للتخصص", "bad"); return; }
    M.mergeClasses(app.st, { classIds: m.classIds, commonIds: m.common, specId: m.spec || null, groups });
    app.modal = null; app.ui.tab = "assign"; commit(); toast("تم الدمج — أكمل إسناد الأساتذة", "ok");
  };

  A.subjSci = (el) => { app.st.subjects.find((s) => s.id === el.dataset.id).sci = el.checked; commit(); };
  A.subjPrefer = (el) => { app.st.subjects.find((s) => s.id === el.dataset.id).prefer = el.value; commit(); };
  A.subjDel = (el) => { app.st.subjects = app.st.subjects.filter((s) => s.id !== el.dataset.id); commit(); };
  A.subjAdd = () => {
    const n = $("newSubName").value.trim();
    if (!n) return toast("أدخل اسم المادة", "bad");
    M.addCustomSubject(app.st, n, $("newSubShort").value); commit();
  };

  A.teacherNew = () => { app.modal = { type: "teacher", editId: null, draft: { name: "", maxPeriods: E.quotaFor(app.st.school.cycle), subjectIds: [] } }; renderModal(); };
  A.teacherEdit = (el) => { const t = app.st.teachers.find((x) => x.id === el.dataset.id); app.modal = { type: "teacher", editId: t.id, draft: { name: t.name, maxPeriods: t.maxPeriods, subjectIds: t.subjectIds.slice() } }; renderModal(); };
  A.tDraft = (el) => { const d = app.modal.draft; d[el.dataset.f] = el.dataset.f === "maxPeriods" ? parseInt(el.value, 10) || 1 : el.value; };
  A.tSub = (el) => { const d = app.modal.draft, id = el.dataset.id; d.subjectIds = el.checked ? [...d.subjectIds, id] : d.subjectIds.filter((x) => x !== id); };
  A.teacherSave = () => {
    const m = app.modal, d = m.draft;
    if (!d.name.trim()) return toast("أدخل اسم الأستاذ", "bad");
    if (m.editId) Object.assign(app.st.teachers.find((t) => t.id === m.editId), { name: d.name.trim(), maxPeriods: d.maxPeriods, subjectIds: d.subjectIds });
    else M.addTeacher(app.st, d.name, d.subjectIds, d.maxPeriods);
    app.modal = null; commit();
  };
  A.teacherDel = (el) => { if (confirmBox("حذف الأستاذ؟ تُفرَّغ إسناداته.")) { M.removeTeacher(app.st, el.dataset.id); commit(); } };
  A.availOpen = (el) => { app.modal = { type: "avail", id: el.dataset.id }; renderModal(); };
  A.availToggle = (el) => {
    const t = app.st.teachers.find((x) => x.id === app.modal.id), k = `${el.dataset.d}-${el.dataset.p}`;
    t.unavailable = t.unavailable.includes(k) ? t.unavailable.filter((x) => x !== k) : [...t.unavailable, k];
    M.reconcile(app.st); save(); renderModal();
  };
  A.availClear = () => { app.st.teachers.find((x) => x.id === app.modal.id).unavailable = []; save(); renderModal(); };

  /* الإسناد */
  const asgOf = (id) => app.st.assignments.find((a) => a.id === id);
  A.asgFilter = (el) => { app.ui.asgFilter = el.value; save(); render(); };
  A.asgTeacher = (el) => { asgOf(el.dataset.aid).parts[+el.dataset.pi].teacherId = el.value || null; commit(); };
  A.asgToAll = (el) => {
    const a = asgOf(el.dataset.aid), sid = a.parts[0].subjectId, tid = a.parts[0].teacherId;
    let n = 0;
    for (const x of app.st.assignments) if (x.parts.length === 1 && x.parts[0].subjectId === sid && !x.parts[0].teacherId) { x.parts[0].teacherId = tid; n++; }
    commit(); toast(`عُيّن الأستاذ في ${n} إسناد آخر`, "ok");
  };
  A.asgPattern = (el) => {
    const a = asgOf(el.dataset.aid), p = M.parsePattern(el.value);
    if (!p.length || M.sum(p) !== a.periods) { toast(`مجموع النمط يجب أن يساوي ${a.periods}`, "bad"); render(); return; }
    a.pattern = p; commit();
  };
  A.asgDel = (el) => { if (confirmBox("حذف هذا الإسناد؟")) { app.st.assignments = app.st.assignments.filter((a) => a.id !== el.dataset.aid); commit(); } };
  A.asgNew = () => { if (!app.st.classes.length) return toast("أضف أقسامًا أولًا", "bad"); if (!app.st.subjects.length) return toast("لا توجد مواد", "bad"); app.modal = { type: "asg", editId: null, draft: newDraft() }; renderModal(); };
  A.asgEdit = (el) => { app.modal = { type: "asg", editId: el.dataset.aid, draft: draftFrom(asgOf(el.dataset.aid)) }; renderModal(); };
  A.draftType = (el) => {
    const d = app.modal.draft, t = el.dataset.t;
    d.type = t;
    const sid = d.parts[0].subjectId;
    if (t === "normal" || t === "merged") d.parts = [d.parts[0]];
    if ((t === "tp" || t === "spec") && d.parts.length < 2) d.parts.push({ subjectId: sid, teacherId: null, label: "" });
    if (t === "normal") d.classIds = d.classIds.slice(0, 1);
    if ((t === "merged" || t === "spec") && d.classIds.length < 2) d.classIds = app.st.classes.slice(0, 2).map((c) => c.id);
    if (t === "tp") { d.periods = 2; d.pattern = "2"; d.classIds = d.classIds.slice(0, 1); }
    if (t === "spec") { d.pattern = M.patternStr(M.defaultPattern(d.periods, false, app.st.school.cycle)); }
    renderModal();
  };
  A.draftClass = (el) => { const d = app.modal.draft, id = el.dataset.id; d.classIds = el.checked ? [...d.classIds, id] : d.classIds.filter((x) => x !== id); };
  A.draftPart = (el) => { const p = app.modal.draft.parts[+el.dataset.i], f = el.dataset.f; p[f] = f === "teacherId" ? el.value || null : el.value; if (f === "subjectId") renderModal(); };
  A.draftAddPart = () => { const d = app.modal.draft; d.parts.push({ subjectId: d.parts[0].subjectId, teacherId: null, label: "" }); renderModal(); };
  A.draftDelPart = (el) => { app.modal.draft.parts.splice(+el.dataset.i, 1); renderModal(); };
  A.draftField = (el) => {
    const d = app.modal.draft, f = el.dataset.f;
    if (f === "cross") d.cross = el.checked;
    else if (f === "periods") { d.periods = Math.max(1, parseInt(el.value, 10) || 1); d.pattern = M.patternStr(M.defaultPattern(d.periods, false, app.st.school.cycle)); renderModal(); }
    else d[f] = el.value;
  };
  A.asgSave = () => {
    const m = app.modal, d = m.draft, st = app.st;
    if (!d.classIds.length) return toast("اختر قسمًا واحدًا على الأقل", "bad");
    if (d.type === "normal" && d.classIds.length > 1) return toast("الإسناد العادي لقسم واحد (استعمل «قسم مدمج»)", "bad");
    if (d.parts.some((p) => !p.subjectId)) return toast("اختر المادة", "bad");
    let pat = M.parsePattern(d.pattern);
    if (!pat.length || M.sum(pat) !== d.periods) { toast(`مجموع النمط يجب أن يساوي ${d.periods} — يرجى التصحيح`, "bad"); return; }
    const data = { classIds: d.classIds.slice(), parts: E.clone(d.parts), periods: d.periods, pattern: pat, morning: d.morning === "yes" ? true : d.morning === "no" ? false : null, crossBreak: d.cross };
    if (m.editId) Object.assign(asgOf(m.editId), data);
    else st.assignments.push({ id: E.uid("a"), ...data });
    app.modal = null; commit();
  };

  /* الجداول */
  A.generate = () => {
    const btn = $("genBtn");
    if (btn) { btn.disabled = true; btn.textContent = "جارٍ التوليد…"; }
    setTimeout(() => {
      const r = generate(); commit();
      toast(r.unplaced.length ? `بقيت ${r.unplaced.length} كتلة بلا موضع` : `تم التوليد في ${r.ms} م.ث`, r.unplaced.length ? "bad" : "ok");
    }, 30);
  };
  A.setView = (el) => { app.ui.view = el.dataset.v; save(); render(); };
  A.setSel = (el) => { app.ui.sel[app.ui.view] = el.value; save(); render(); };
  A.cell = (el) => { app.modal = { type: "cell", id: el.dataset.id }; renderModal(); };
  A.unplace = (el) => { app.st.placements = app.st.placements.filter((p) => p.id !== el.dataset.id); app.modal = null; save(); render(); };
  A.emptyCell = (el) => { app.modal = { type: "place", day: +el.dataset.day, period: +el.dataset.period }; renderModal(); };
  A.placeManual = (el) => {
    const m = app.modal, b = M.unplacedBlocks(app.st).find((x) => x.id === el.dataset.bid);
    if (!b) return;
    app.st.placements.push({ id: b.id, aid: b.aid, day: m.day, period: m.period, length: b.length });
    app.modal = null; save(); render();
  };
  const gridsFor = (kind) => (kind === "classes" ? app.st.classes : app.st.teachers).map((x) => M.buildGrid(app.st, kind === "classes" ? "class" : "teacher", x.id));
  A.exportPdf = async (el) => {
    const st = app.st, scope = el.dataset.scope;
    const grids = scope === "one" ? [M.buildGrid(st, app.ui.view, currentSel())] : gridsFor(scope);
    if (!grids.length) return toast("لا يوجد ما يُصدَّر", "bad");
    toast("جارٍ إنشاء PDF…");
    await new Promise((r) => setTimeout(r, 30));
    try {
      const blob = E.exp.pdf(grids.map((g) => E.exp.drawGrid(g, st.school)));
      await E.exp.save(`emploi-${scope === "one" ? grids[0].title.replace(/[^\u0600-\u06FFa-zA-Z0-9]+/g, "_") : scope}.pdf`, blob);
    } catch (e) { toast("تعذّر إنشاء PDF: " + e.message, "bad"); }
  };
  A.exportXlsx = async () => {
    const st = app.st, grids = [...gridsFor("classes"), ...gridsFor("teachers")];
    if (!grids.length) return toast("لا يوجد ما يُصدَّر", "bad");
    try { await E.exp.save("emploi-du-temps.xlsx", E.exp.xlsx(grids)); } catch (e) { toast("تعذّر إنشاء Excel: " + e.message, "bad"); }
  };
  A.printNow = () => globalThis.print();

  function dispatch(ev) {
    const el = ev.target.closest("[data-act]");
    if (!el) return;
    const act = el.dataset.act, type = ev.type;
    const isField = el.tagName === "INPUT" && el.type !== "checkbox" || el.tagName === "SELECT" || el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && el.type === "checkbox");
    if (isField && type === "click") return;                       // الحقول تُعالَج عند change
    if (!isField && type === "change") return;
    const fn = A[act];
    if (fn) fn(el, ev);
  }

  E.boot = function () {
    load();
    document.addEventListener("click", dispatch);
    document.addEventListener("change", dispatch);
    document.addEventListener("change", (ev) => {
      if (ev.target.id !== "importFile") return;
      const f = ev.target.files[0];
      if (!f) return;
      const r = new FileReader();
      r.onload = () => {
        try {
          const o = JSON.parse(r.result);
          if (!o.school || !Array.isArray(o.assignments)) throw new Error("ملف غير صالح");
          app.st = o; app.st.placements = app.st.placements || []; commit(); toast("تم الاستيراد", "ok");
        } catch (e) { toast("تعذّر الاستيراد: " + e.message, "bad"); }
      };
      r.readAsText(f);
    });
    render();
  };
})();
