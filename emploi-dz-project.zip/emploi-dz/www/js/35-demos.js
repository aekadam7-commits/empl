/* نماذج تجريبية جاهزة للتجربة السريعة */
(function () {
  const E = globalThis.EDT;
  const M = E.model;
  const D = (E.demos = {});

  /* plan: [{name, subjects:[رموز], classes:[أسماء] | "*", max?}] — يعيّن الأستاذ لكل إسناد أحادي الجزء */
  function autoAssign(st, plan) {
    for (const item of plan) {
      const t = M.addTeacher(st, item.name, item.subjects, item.max);
      for (const a of st.assignments) {
        if (a.parts.length !== 1 || a.parts[0].teacherId) continue;
        if (!item.subjects.includes(a.parts[0].subjectId)) continue;
        const names = a.classIds.map((c) => M.className(st, c));
        if (item.classes === "*" || names.some((n) => item.classes.includes(n))) a.parts[0].teacherId = t.id;
      }
    }
  }
  /* تطبيقات: تُخصم الساعات من المواد العادية وتُضاف حصة بأفواج متزامنة */
  function addTP(st, className, subjectIds, periods) {
    const c = st.classes.find((x) => x.name === className);
    for (const sid of subjectIds) {
      const a = st.assignments.find((x) => x.classIds.length === 1 && x.classIds[0] === c.id && x.parts.length === 1 && x.parts[0].subjectId === sid);
      if (a) { a.periods -= periods; a.pattern = M.defaultPattern(a.periods, false, st.school.cycle); }
    }
    st.assignments = st.assignments.filter((a) => a.periods > 0);
    st.assignments.push(M.makeAssignment([c.id], subjectIds.map((sid) => ({ subjectId: sid, teacherId: null, label: "" })), periods, [periods]));
  }
  function setSchool(st, patch) { Object.assign(st.school, patch); }

  D.secondaryTech = function () {
    const st = M.blank("secondary");
    setSchool(st, { name: "ثانوية تقنية — نموذج", wilaya: "سطيف", commune: "سطيف", director: "", phone: "" });
    M.addClass(st, "1sct", 1);
    M.addClass(st, "2tech", 1);
    M.addClass(st, "3tech", 1);
    addTP(st, "1ع ت1", ["nat", "phys"], 2);
    const c2 = st.classes.find((c) => c.name === "2تق1").id, c3 = st.classes.find((c) => c.name === "3تق1").id;
    M.mergeClasses(st, { classIds: [c2, c3], commonIds: ["math", "phys", "ar", "fr", "en", "phil", "hist", "isl", "pe"], specId: "engi", groups: E.DEFAULT_SPEC_GROUPS.slice() });
    autoAssign(st, [
      { name: "أ. سعيدي كمال", subjects: ["math"], classes: "*" },
      { name: "أ. براهيمي نادية", subjects: ["phys"], classes: "*" },
      { name: "أ. عمران لطفي", subjects: ["nat"], classes: "*" },
      { name: "أ. حميدي رشيد", subjects: ["tech"], classes: "*" },
      { name: "أ. غربي سفيان", subjects: ["it"], classes: "*" },
      { name: "أ. قادة صليحة", subjects: ["ar", "isl"], classes: "*" },
      { name: "أ. بن علي فريد", subjects: ["fr"], classes: "*" },
      { name: "أ. بوكروم إيمان", subjects: ["en"], classes: "*" },
      { name: "أ. زياني عبد الرحمن", subjects: ["phil", "hist"], classes: "*" },
      { name: "أ. بلعيد يوسف", subjects: ["pe"], classes: "*" },
    ]);
    /* أستاذا العلوم والفيزياء في التطبيقات */
    const tNat = st.teachers.find((t) => t.subjectIds.includes("nat")).id;
    const tPhys = st.teachers.find((t) => t.subjectIds.includes("phys")).id;
    const tp = st.assignments.find((a) => a.parts.length === 2 && a.parts[0].subjectId === "nat");
    tp.parts[0].teacherId = tNat; tp.parts[1].teacherId = tPhys;
    /* تخصصات الهندسة: ثلاثة أساتذة */
    const spec = st.assignments.find((a) => a.parts.length === 3);
    E.DEFAULT_SPEC_GROUPS.forEach((g, i) => { spec.parts[i].teacherId = M.addTeacher(st, `أ. مهندس ${g.replace("هندسة ", "")}`, ["engi"], 16).id; });
    return st;
  };

  D.middle = function () {
    const st = M.blank("middle");
    setSchool(st, { name: "متوسطة الشهيد محمد العربي بن مهيدي", wilaya: "قسنطينة", commune: "قسنطينة", phone: "031 92 00 00" });
    for (const [lv, n] of [["1m", 1], ["1m", 2], ["2m", 1], ["4m", 1]]) M.addClass(st, lv, n);
    autoAssign(st, [
      { name: "أ. قاسمي ليلى", subjects: ["ar"], classes: ["1م1", "1م2"] },
      { name: "أ. بوعلام نصر الدين", subjects: ["ar"], classes: ["2م1", "4م1"] },
      { name: "أ. بن يوسف كريم", subjects: ["math"], classes: "*" },
      { name: "أ. بوزيد آمال", subjects: ["fr"], classes: "*" },
      { name: "أ. حمدان سامي", subjects: ["en"], classes: "*" },
      { name: "أ. عرعار فتيحة", subjects: ["isl", "civ"], classes: "*" },
      { name: "أ. شريف نبيل", subjects: ["hist"], classes: "*" },
      { name: "أ. زروقي ياسمين", subjects: ["nat"], classes: "*" },
      { name: "أ. مزيان محمد", subjects: ["phy"], classes: "*" },
      { name: "أ. حاج سعيد رفيق", subjects: ["it"], classes: "*" },
      { name: "أ. عثماني سلمى", subjects: ["art", "mus"], classes: "*" },
      { name: "أ. دحمان خالد", subjects: ["pe"], classes: "*" },
    ]);
    return st;
  };

  D.primary = function () {
    const st = M.blank("primary");
    setSchool(st, { name: "ابتدائية الشهيد العربي بن مهيدي", wilaya: "وهران", commune: "وهران", phone: "041 33 00 00" });
    for (const lv of ["3p", "4p", "5p"]) M.addClass(st, lv, 1);
    const cls = ["ar", "math", "isl", "civ", "sci"];
    autoAssign(st, [
      { name: "أ. بوعبد الله سمير", subjects: cls, classes: ["3إ1"] },
      { name: "أ. مرابط هدى", subjects: cls, classes: ["4إ1"] },
      { name: "أ. عبدي يوسف", subjects: cls, classes: ["5إ1"] },
      { name: "أ. بن عمر سامية", subjects: ["fr"], classes: "*" },
      { name: "أ. قليل ريمة", subjects: ["artp"], classes: "*" },
      { name: "أ. حركات أمين", subjects: ["pe"], classes: "*" },
    ]);
    return st;
  };
})();
