/* الشبكة الزمنية والاستراحات */
(function () {
  const E = globalThis.EDT;
  const FULL = [["08:00","09:00"],["09:00","10:00"],["10:15","11:15"],["11:15","12:15"],["13:30","14:30"],["14:30","15:30"],["15:30","16:30"],["16:30","17:30"]];
  const PRIM = [["08:00","08:45"],["08:45","09:30"],["09:30","10:15"],["10:30","11:15"],["11:15","12:00"],["13:30","14:15"],["14:15","15:00"]];
  const mk = (t) => t.map(([start, end], index) => ({ index, label: "الحصة " + (index + 1), start, end }));
  /* barriers: فهارس الحصص التي تليها استراحة (لا تُعبَر إلا باستثناء) */
  E.gridFor = function (cycle) {
    if (cycle === "primary")
      return { periods: mk(PRIM), barriers: [2, 4], shortBreak: 2, afternoonStart: 5, breaks: { 2: "استراحة", 4: "استراحة الغداء" }, minutes: 45 };
    return { periods: mk(FULL), barriers: [1, 3], shortBreak: 1, afternoonStart: 4, breaks: { 1: "استراحة", 3: "استراحة الغداء" }, minutes: 60 };
  };
  /* هل تعبر الكتلة استراحة غير مسموح بعبورها؟ */
  E.crosses = (start, len, barriers, allowed) =>
    barriers.some((b) => start <= b && start + len - 1 > b && !(allowed || []).includes(b));
  E.slotCapacity = (grid, thursdayMorningOnly) => {
    const full = grid.periods.length * E.DAY_COUNT;
    return thursdayMorningOnly ? full - (grid.periods.length - grid.afternoonStart) : full;
  };
})();
