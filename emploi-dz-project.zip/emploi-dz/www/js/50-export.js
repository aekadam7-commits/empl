/* التصدير بلا مكتبات خارجية: xlsx (zip بلا ضغط) + pdf (صور JPEG من canvas) + حفظ الملفات */
(function () {
  const E = globalThis.EDT;
  const X = (E.exp = {});
  const enc = new TextEncoder();

  /* ---------------- حفظ الملفات ---------------- */
  function blobToBase64(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(",")[1]);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(blob);
    });
  }
  X.save = async function (name, blob) {
    const cap = globalThis.Capacitor;
    if (cap && cap.isNativePlatform && cap.isNativePlatform()) {
      const FS = (cap.Plugins && cap.Plugins.Filesystem) || cap.registerPlugin("Filesystem");
      const Share = (cap.Plugins && cap.Plugins.Share) || cap.registerPlugin("Share");
      const data = await blobToBase64(blob);
      const r = await FS.writeFile({ path: name, data, directory: "CACHE" });
      await Share.share({ title: name, url: r.uri, dialogTitle: "حفظ أو مشاركة الملف" });
      return;
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  /* ---------------- ZIP (بدون ضغط) ---------------- */
  const CRC = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    return t;
  })();
  const crc32 = (u8) => { let c = 0xffffffff; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  function zip(files) {
    const parts = [], central = [];
    let offset = 0;
    const u16 = (v) => [v & 255, (v >> 8) & 255];
    const u32 = (v) => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
    for (const f of files) {
      const name = enc.encode(f.name), data = typeof f.data === "string" ? enc.encode(f.data) : f.data;
      const crc = crc32(data);
      const head = new Uint8Array([0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)]);
      parts.push(head, name, data);
      central.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)]), name);
      offset += head.length + name.length + data.length;
    }
    const cdSize = central.reduce((s, x) => s + x.length, 0);
    const end = new Uint8Array([0x50, 0x4b, 5, 6, 0, 0, 0, 0, ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(offset), 0, 0]);
    return new Blob([...parts, ...central, end], { type: "application/zip" });
  }

  /* ---------------- XLSX ---------------- */
  const xe = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
  const colName = (i) => { let s = ""; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };

  function sheetXml(grid) {
    const cols = grid.days.length + 1;
    const rows = [], merges = [];
    const cell = (r, c, text, style) => `<c r="${colName(c)}${r}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xe(text)}</t></is></c>`;
    rows.push(`<row r="1" ht="30" customHeight="1">${cell(1, 0, grid.title, 1)}</row>`); merges.push(`A1:${colName(cols - 1)}1`);
    rows.push(`<row r="2" ht="22" customHeight="1">${cell(2, 0, grid.subtitle, 2)}</row>`); merges.push(`A2:${colName(cols - 1)}2`);
    rows.push(`<row r="3" ht="24" customHeight="1">${cell(3, 0, "الحصة / اليوم", 3)}${grid.days.map((d, i) => cell(3, i + 1, d, 3)).join("")}</row>`);
    grid.rows.forEach((row, ri) => {
      const r = ri + 4;
      if (row.kind === "break") {
        rows.push(`<row r="${r}" ht="16" customHeight="1">${cell(r, 0, row.label, 4)}${grid.days.map((_, i) => cell(r, i + 1, "", 4)).join("")}</row>`);
        return;
      }
      let cs = cell(r, 0, `${row.label}\n${row.time}`, 5);
      grid.days.forEach((_, di) => {
        const c = grid.cells[ri][di];
        if (c && c.skip) { cs += cell(r, di + 1, "", 6); return; }
        if (c && c.lines) {
          cs += cell(r, di + 1, c.lines.join("\n"), 7 + (E.PALETTE.indexOf(c.color) >= 0 ? E.PALETTE.indexOf(c.color) : 0));
          if (c.rowspan > 1) merges.push(`${colName(di + 1)}${r}:${colName(di + 1)}${r + c.rowspan - 1}`);
        } else cs += cell(r, di + 1, "", 6);
      });
      rows.push(`<row r="${r}" ht="58" customHeight="1">${cs}</row>`);
    });
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="18"/><cols><col min="1" max="1" width="16" customWidth="1"/><col min="2" max="${cols}" width="24" customWidth="1"/></cols><sheetData>${rows.join("")}</sheetData><mergeCells count="${merges.length}">${merges.map((m) => `<mergeCell ref="${m}"/>`).join("")}</mergeCells><pageSetup orientation="landscape" paperSize="9" fitToHeight="1"/></worksheet>`;
  }
  function stylesXml() {
    const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>',
      '<fill><patternFill patternType="solid"><fgColor rgb="FFD6E4D9"/></patternFill></fill>', '<fill><patternFill patternType="solid"><fgColor rgb="FFEEEEEE"/></patternFill></fill>',
      ...E.PALETTE.map((c) => `<fill><patternFill patternType="solid"><fgColor rgb="FF${c.slice(1).toUpperCase()}"/></patternFill></fill>`)];
    const al = '<alignment horizontal="center" vertical="center" wrapText="1"/>';
    const xf = (fill, font, border) => `<xf numFmtId="0" fontId="${font}" fillId="${fill}" borderId="${border}" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">${al}</xf>`;
    const xfs = [xf(0, 0, 0), xf(0, 1, 0), xf(0, 0, 0), xf(2, 1, 1), xf(3, 0, 1), xf(2, 1, 1), xf(0, 0, 1), ...E.PALETTE.map((_, i) => xf(4 + i, 0, 1))];
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="12"/><name val="Arial"/></font></fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FF888888"/></left><right style="thin"><color rgb="FF888888"/></right><top style="thin"><color rgb="FF888888"/></top><bottom style="thin"><color rgb="FF888888"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  }
  X.xlsx = function (grids) {
    const used = new Set();
    const names = grids.map((g, i) => {
      let n = g.title.replace(/^جدول (القسم|الأستاذ): /, "").replace(/[\[\]:*?\/\\]/g, " ").trim().slice(0, 28) || "ورقة" + (i + 1);
      while (used.has(n)) n = n.slice(0, 26) + "_" + i;
      used.add(n);
      return n;
    });
    const files = [
      { name: "[Content_Types].xml", data: `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${grids.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>` },
      { name: "_rels/.rels", data: `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
      { name: "xl/workbook.xml", data: `<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xe(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>` },
      { name: "xl/_rels/workbook.xml.rels", data: `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${grids.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${grids.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
      { name: "xl/styles.xml", data: stylesXml() },
      ...grids.map((g, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(g) })),
    ];
    const blob = zip(files);
    return new Blob([blob], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  };

  /* ---------------- رسم الجدول على canvas (للـ PDF) ---------------- */
  const FONT = "Tahoma, 'Segoe UI', 'Noto Naskh Arabic', 'Noto Sans Arabic', Arial, sans-serif";
  function wrap(ctx, text, maxW) {
    const words = String(text).split(/\s+/), lines = [];
    let cur = "";
    for (const w of words) {
      const t = cur ? cur + " " + w : w;
      if (ctx.measureText(t).width <= maxW || !cur) cur = t; else { lines.push(cur); cur = w; }
    }
    if (cur) lines.push(cur);
    return lines;
  }
  X.drawGrid = function (grid, school, W = 1754, H = 1240) {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, W, H);
    ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillStyle = "#14301f"; ctx.font = `bold 40px ${FONT}`; ctx.fillText(grid.title, W / 2, 56);
    ctx.fillStyle = "#555"; ctx.font = `24px ${FONT}`; ctx.fillText(grid.subtitle, W / 2, 104);
    const left = 40, right = W - 40, top = 140, bottom = H - 90;
    const firstW = 190, dayW = (right - left - firstW) / grid.days.length;
    const headH = 46;
    const nP = grid.rows.filter((r) => r.kind === "period").length, nB = grid.rows.length - nP;
    const breakH = 26;
    const rowH = (bottom - top - headH - nB * breakH) / nP;
    const xOf = (di) => right - firstW - (di + 1) * dayW;       // اليوم الأول يمين الجدول
    ctx.strokeStyle = "#777"; ctx.lineWidth = 1.5;
    // رأس
    ctx.fillStyle = "#d6e4d9"; ctx.fillRect(right - firstW, top, firstW, headH); ctx.strokeRect(right - firstW, top, firstW, headH);
    ctx.fillStyle = "#14301f"; ctx.font = `bold 24px ${FONT}`; ctx.fillText("الحصة / اليوم", right - firstW / 2, top + headH / 2);
    grid.days.forEach((d, di) => { const x = xOf(di); ctx.fillStyle = "#d6e4d9"; ctx.fillRect(x, top, dayW, headH); ctx.strokeRect(x, top, dayW, headH); ctx.fillStyle = "#14301f"; ctx.fillText(d, x + dayW / 2, top + headH / 2); });
    // صفوف
    const ys = []; let y = top + headH;
    grid.rows.forEach((r) => { ys.push(y); y += r.kind === "break" ? breakH : rowH; });
    ys.push(y);
    grid.rows.forEach((r, ri) => {
      if (r.kind !== "break") return;
      const y0 = ys[ri], h = ys[ri + 1] - y0;
      ctx.fillStyle = "#eee"; ctx.fillRect(left, y0, right - left, h); ctx.strokeRect(left, y0, right - left, h);
      ctx.fillStyle = "#666"; ctx.font = `bold 18px ${FONT}`; ctx.fillText(r.label, right - firstW / 2, y0 + h / 2);
    });
    grid.rows.forEach((r, ri) => {
      const y0 = ys[ri], h = ys[ri + 1] - y0;
      if (r.kind === "break") return;
      ctx.fillStyle = "#e9f1ea"; ctx.fillRect(right - firstW, y0, firstW, h); ctx.strokeRect(right - firstW, y0, firstW, h);
      ctx.fillStyle = "#14301f"; ctx.font = `bold 24px ${FONT}`; ctx.fillText(r.label, right - firstW / 2, y0 + h / 2 - 16);
      ctx.font = `20px ${FONT}`; ctx.fillStyle = "#555"; ctx.fillText(r.time, right - firstW / 2, y0 + h / 2 + 16);
      grid.days.forEach((_, di) => {
        const c = grid.cells[ri][di], x = xOf(di);
        if (c && c.skip) return;
        const hh = c && c.rowspan ? ys[ri + c.rowspan] - y0 : h;
        ctx.fillStyle = c && c.color ? c.color : "#fff"; ctx.fillRect(x, y0, dayW, hh); ctx.strokeRect(x, y0, dayW, hh);
        if (!c || !c.lines) return;
        let size = 26, lines;
        for (; size >= 13; size -= 1) {
          ctx.font = `bold ${size}px ${FONT}`;
          lines = c.lines.flatMap((l) => wrap(ctx, l, dayW - 16));
          if (lines.length * size * 1.3 <= hh - 10) break;
        }
        ctx.fillStyle = "#111";
        const lh = size * 1.3, y1 = y0 + hh / 2 - (lines.length * lh) / 2 + lh / 2;
        lines.forEach((l, i) => { ctx.font = `${i === 0 ? "bold " : ""}${size}px ${FONT}`; ctx.fillText(l, x + dayW / 2, y1 + i * lh); });
      });
    });
    // تذييل
    ctx.fillStyle = "#333"; ctx.font = `22px ${FONT}`;
    ctx.textAlign = "right"; ctx.fillText(`مدير المؤسسة: ${school.director || "........................"}`, right, H - 50);
    ctx.textAlign = "left"; ctx.fillText(`مستشار التوجيه: ${school.counselor || "........................"}`, left, H - 50);
    ctx.textAlign = "center"; ctx.fillStyle = "#777"; ctx.font = `18px ${FONT}`;
    ctx.fillText(grid.kind === "teacher" ? `مجموع الحصص: ${grid.hours} ساعة` : `الحجم الساعي: ${grid.hours} ساعة`, W / 2, H - 50);
    return cv;
  };

  /* ---------------- PDF من صور ---------------- */
  X.pdf = function (canvases) {
    const chunks = [], offsets = [];
    let pos = 0;
    const push = (x) => { const u = typeof x === "string" ? enc.encode(x) : x; chunks.push(u); pos += u.length; };
    const obj = (n, body) => { offsets[n] = pos; push(`${n} 0 obj\n`); if (typeof body === "string") push(body); else body.forEach(push); push("\nendobj\n"); };
    push("%PDF-1.4\n");
    const n = canvases.length;
    obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
    obj(2, `<< /Type /Pages /Kids [${canvases.map((_, i) => `${3 + 3 * i} 0 R`).join(" ")}] /Count ${n} >>`);
    canvases.forEach((cv, i) => {
      const jpg = atob(cv.toDataURL("image/jpeg", 0.92).split(",")[1]);
      const bytes = new Uint8Array(jpg.length);
      for (let k = 0; k < jpg.length; k++) bytes[k] = jpg.charCodeAt(k);
      const page = 3 + 3 * i, content = page + 1, img = page + 2;
      const cs = "q 842 0 0 595 0 0 cm /Im0 Do Q";
      obj(page, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /XObject << /Im0 ${img} 0 R >> >> /Contents ${content} 0 R >>`);
      obj(content, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`);
      obj(img, [`<< /Type /XObject /Subtype /Image /Width ${cv.width} /Height ${cv.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${bytes.length} >>\nstream\n`, bytes, "\nendstream"]);
    });
    const xref = pos, total = 3 + 3 * n;
    let x = `xref\n0 ${total}\n0000000000 65535 f \n`;
    for (let i = 1; i < total; i++) x += String(offsets[i]).padStart(10, "0") + " 00000 n \n";
    push(x + `trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    return new Blob(chunks, { type: "application/pdf" });
  };
})();
