/* المُجدوِل.
 * كل كتلة (block) تحجز مجموعة موارد معًا: الأقسام المشاركة + كل أساتذة الأجزاء المتزامنة.
 * هذا يغطي بنفس الصيغة: حصة عادية، تطبيقات بفوجين، قسم مدمج، تخصصات متزامنة.
 * الخوارزمية: ترتيب بحسب الصعوبة → وضع جشع بالتقييم → إصلاح بإزاحة كتلتين على الأكثر
 *            → بحث محلي يقلل الثغرات → إعادة محاولات بعشوائية مبذورة.
 */
(function () {
  const E = globalThis.EDT;
  const S = (E.solver = {});
  const W_CLASS_GAP = 46, W_TEACHER_GAP = 14;

  function mulberry32(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  class Board {
    constructor(inp) {
      this.inp = inp;
      this.occ = new Map();   // res|day|period -> blockId
      this.at = new Map();    // blockId -> {b, day, period}
      this.sess = new Map();  // aid|day -> عدد الكتل
    }
    put(b, d, p) {
      this.at.set(b.id, { b, day: d, period: p });
      for (const r of b.res) for (let k = 0; k < b.length; k++) this.occ.set(`${r}|${d}|${p + k}`, b.id);
      const sk = `${b.aid}|${d}`;
      this.sess.set(sk, (this.sess.get(sk) || 0) + 1);
    }
    remove(id) {
      const x = this.at.get(id);
      if (!x) return;
      const { b, day, period } = x;
      this.at.delete(id);
      for (const r of b.res) for (let k = 0; k < b.length; k++) this.occ.delete(`${r}|${day}|${period + k}`);
      const sk = `${b.aid}|${day}`;
      this.sess.set(sk, (this.sess.get(sk) || 1) - 1);
    }
    sessCount(aid, day, ignore) {
      let n = this.sess.get(`${aid}|${day}`) || 0;
      if (ignore) for (const id of ignore) { const x = this.at.get(id); if (x && x.b.aid === aid && x.day === day) n--; }
      return n;
    }
    can(b, d, p, ignore, relax) {
      const inp = this.inp, len = b.length, last = p + len - 1;
      if (p < 0 || last >= inp.periodCount) return false;
      if (E.crosses(p, len, inp.barriers, b.cross)) return false;
      if (b.morning && last >= inp.afternoonStart) return false;
      if (inp.thursdayMorningOnly && d === 4 && last >= inp.afternoonStart) return false;
      for (const r of b.res)
        for (let k = 0; k < len; k++) {
          const key = `${r}|${d}|${p + k}`;
          const o = this.occ.get(key);
          if (o && !(ignore && ignore.has(o))) return false;
          if (inp.unavailable.has(key)) return false;
        }
      if (!relax && this.sessCount(b.aid, d, ignore) > 0) return false;
      return true;
    }
    conflicts(b, d, p) {
      const ids = new Set();
      for (const r of b.res) for (let k = 0; k < b.length; k++) { const o = this.occ.get(`${r}|${d}|${p + k}`); if (o) ids.add(o); }
      return ids;
    }
    /* ملخص مورد في يوم، مع إضافة اختيارية لخلايا مرشحة */
    span(r, d, ep, el) {
      let first = -1, last = -1, count = 0;
      for (let p = 0; p < this.inp.periodCount; p++) {
        if (this.occ.has(`${r}|${d}|${p}`) || (el && p >= ep && p < ep + el)) {
          if (first < 0) first = p;
          last = p; count++;
        }
      }
      return { first: first < 0 ? 0 : first, gaps: first < 0 ? 0 : last - first + 1 - count, count };
    }
    dayCost(res, d) {
      let c = 0;
      for (const r of res) {
        const s = this.span(r, d);
        if (r[0] === "c") c += s.gaps * W_CLASS_GAP + (s.count ? s.first * 2 : 0);
        else c += s.gaps * W_TEACHER_GAP;
      }
      return c;
    }
  }

  function prefCost(b, p, inp) {
    const morning = p + b.length - 1 < inp.afternoonStart;
    if (b.prefer === "morning") return morning ? 0 : 6;
    if (b.prefer === "afternoon") return morning ? 8 : 0;
    return 0;
  }

  function score(board, b, d, p) {
    const inp = board.inp;
    let v = 0;
    for (const r of b.res) {
      const s = board.span(r, d, p, b.length);
      if (r[0] === "c") {
        v -= s.gaps * W_CLASS_GAP + s.first * 3 + (s.count - b.length) * 5;
      } else {
        v -= s.gaps * W_TEACHER_GAP;
        if (s.count - b.length > 0) v += 6;
      }
    }
    return v - prefCost(b, p, inp) * 2;
  }

  function bestFree(board, b, relax, rand, jitter) {
    const inp = board.inp;
    let best = null;
    for (let d = 0; d < inp.days; d++)
      for (let p = 0; p < inp.periodCount; p++) {
        if (!board.can(b, d, p, null, relax)) continue;
        const v = score(board, b, d, p) + (jitter ? rand() * 2 : 0);
        if (!best || v > best.v + 0.001) best = { d, p, v };
      }
    return best;
  }

  function attempt(board, b, d, p, relax) {
    const conflicts = board.conflicts(b, d, p);
    if (conflicts.size > 3) return false;
    if (!board.can(b, d, p, conflicts, relax)) return false;
    const saved = [...conflicts].map((id) => ({ ...board.at.get(id) }));
    for (const id of conflicts) board.remove(id);
    board.put(b, d, p);
    const moved = [];
    for (const old of saved) {
      const slot = bestFree(board, old.b, relax, null, false);
      if (!slot) {
        board.remove(b.id);
        for (const id of moved) board.remove(id);
        for (const o of saved) board.put(o.b, o.day, o.period);
        return false;
      }
      board.put(old.b, slot.d, slot.p);
      moved.push(old.b.id);
    }
    return true;
  }

  function improve(board, rand, passes) {
    const inp = board.inp;
    for (let pass = 0; pass < passes; pass++) {
      let moved = false;
      const ids = [...board.at.keys()];
      for (let i = ids.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [ids[i], ids[j]] = [ids[j], ids[i]]; }
      for (const id of ids) {
        const x = board.at.get(id);
        if (!x) continue;
        const { b, day: d0, period: p0 } = x;
        const T0 = board.dayCost(b.res, d0);
        const pref0 = prefCost(b, p0, inp);
        board.remove(id);
        const baseWithout = board.dayCost(b.res, d0);
        const X = new Map();
        const without = (d) => { if (!X.has(d)) X.set(d, board.dayCost(b.res, d)); return X.get(d); };
        let best = null;
        for (let d = 0; d < inp.days; d++)
          for (let p = 0; p < inp.periodCount; p++) {
            if (d === d0 && p === p0) continue;
            if (!board.can(b, d, p, null, false)) continue;
            board.put(b, d, p);
            const after = d === d0 ? board.dayCost(b.res, d0) : baseWithout + board.dayCost(b.res, d);
            board.remove(id);
            const before = d === d0 ? T0 : T0 + without(d);
            const delta = after + prefCost(b, p, inp) - (before + pref0);
            if (delta < -0.01 && (!best || delta < best.delta)) best = { d, p, delta };
          }
        if (best) { board.put(b, best.d, best.p); moved = true; }
        else board.put(b, d0, p0);
      }
      if (!moved) break;
    }
  }

  function totals(board) {
    const seen = new Set();
    let classGaps = 0, teacherGaps = 0;
    for (const { b, day } of board.at.values())
      for (const r of b.res) {
        const k = `${r}|${day}`;
        if (seen.has(k)) continue;
        seen.add(k);
        const g = board.span(r, day).gaps;
        if (r[0] === "c") classGaps += g; else teacherGaps += g;
      }
    return { classGaps, teacherGaps };
  }

  function generateOnce(inp, relax, rand, jitter) {
    const board = new Board(inp);
    const load = new Map();
    for (const b of inp.blocks) for (const r of b.res) if (r[0] === "t") load.set(r, (load.get(r) || 0) + b.length);
    const ranked = inp.blocks.map((b) => ({
      b,
      rank: b.length * 100 + b.res.length * 22 + (b.morning ? 35 : 0) + (b.prefer === "afternoon" ? 8 : 0) +
        Math.max(0, ...b.res.filter((r) => r[0] === "t").map((r) => load.get(r) || 0)) * 2 + (jitter ? rand() * 3 : 0),
    }));
    ranked.sort((a, c) => c.rank - a.rank || (a.b.id < c.b.id ? -1 : 1));
    let pending = [];
    for (const { b } of ranked) {
      const slot = bestFree(board, b, relax, rand, jitter);
      if (slot) board.put(b, slot.d, slot.p); else pending.push(b);
    }
    for (let pass = 0; pass < 8 && pending.length; pass++) {
      const next = [];
      let progress = false;
      for (const b of pending) {
        const slots = [];
        for (let d = 0; d < inp.days; d++)
          for (let p = 0; p < inp.periodCount; p++) {
            const c = board.conflicts(b, d, p);
            if (c.size > 3 || !board.can(b, d, p, c, relax)) continue;
            slots.push({ d, p, v: score(board, b, d, p) + (jitter ? rand() : 0) });
          }
        slots.sort((a, c) => c.v - a.v);
        let ok = false;
        for (const s of slots) if (attempt(board, b, s.d, s.p, relax)) { ok = true; progress = true; break; }
        if (!ok) next.push(b);
      }
      pending = next;
      if (!progress) break;
    }
    improve(board, rand, 5);
    const t = totals(board);
    let pref = 0;
    for (const { b, period } of board.at.values()) pref += prefCost(b, period, inp);
    const missed = pending.reduce((s, b) => s + b.length, 0);
    return {
      board, pending,
      cost: missed * 10000 + t.classGaps * W_CLASS_GAP + t.teacherGaps * W_TEACHER_GAP + pref,
      classGaps: t.classGaps, teacherGaps: t.teacherGaps, missed,
    };
  }

  S.solve = function (inp, opts = {}) {
    const budget = opts.budgetMs || 3000;
    const t0 = Date.now();
    let best = null;
    for (const relax of [false, true]) {
      const restarts = relax ? 6 : 14;
      for (let i = 0; i < restarts; i++) {
        const rand = mulberry32(inp.seed * 7919 + i * 97 + (relax ? 10007 : 0));
        const r = generateOnce(inp, relax, rand, i > 0);
        if (!best || r.cost < best.cost) best = r;
        if (best.missed === 0 && best.classGaps === 0 && best.teacherGaps === 0) break;
        if (Date.now() - t0 > budget && i >= 2) break;
      }
      if (best && best.missed === 0) break;
    }
    const placements = [...best.board.at.values()].map(({ b, day, period }) => ({ id: b.id, aid: b.aid, day, period, length: b.length }));
    placements.sort((a, c) => (a.id < c.id ? -1 : 1));
    return {
      placements, unplaced: best.pending.map((b) => b.id),
      classGaps: best.classGaps, teacherGaps: best.teacherGaps, ms: Date.now() - t0,
    };
  };

  /* هل يمكن وضع كتلة يدويًا في (يوم، حصة) مع الحصص الموضوعة الحالية؟ */
  S.canPlace = function (inp, placements, blockId, day, period) {
    const byId = new Map(inp.blocks.map((b) => [b.id, b]));
    const board = new Board(inp);
    for (const p of placements) { const b = byId.get(p.id); if (b && p.id !== blockId) board.put(b, p.day, p.period); }
    const b = byId.get(blockId);
    return !!b && board.can(b, day, period, null, true);
  };

  /* تدقيق مستقل: يُرجع قائمة الأخطاء (فارغة = سليم) */
  S.audit = function (inp, placements) {
    const errs = [];
    const byId = new Map(inp.blocks.map((b) => [b.id, b]));
    const occ = new Map();
    for (const pl of placements) {
      const b = byId.get(pl.id);
      if (!b) { errs.push("كتلة مجهولة " + pl.id); continue; }
      const last = pl.period + b.length - 1;
      if (pl.period < 0 || last >= inp.periodCount) errs.push("خارج الشبكة " + pl.id);
      if (E.crosses(pl.period, b.length, inp.barriers, b.cross)) errs.push("تعبر استراحة " + pl.id);
      if (b.morning && last >= inp.afternoonStart) errs.push("مادة علمية مساءً " + pl.id);
      if (inp.thursdayMorningOnly && pl.day === 4 && last >= inp.afternoonStart) errs.push("الخميس مساءً " + pl.id);
      for (const r of b.res)
        for (let k = 0; k < b.length; k++) {
          const key = `${r}|${pl.day}|${pl.period + k}`;
          if (occ.has(key)) errs.push(`تعارض ${key} بين ${occ.get(key)} و ${pl.id}`);
          occ.set(key, pl.id);
          if (inp.unavailable.has(key)) errs.push("أستاذ غير متاح " + key);
        }
    }
    return errs;
  };
})();
