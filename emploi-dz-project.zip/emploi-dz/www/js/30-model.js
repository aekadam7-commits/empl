/* نموذج البيانات.
 * الإسناد (assignment) = وحدة تدريس تُوضع في الجدول:
 *   classIds : الأقسام المشاركة (أكثر من قسم = قسم مدمج)
 *   parts    : أجزاء متزامنة (فوج/تخصص)، لكل جزء مادة وأستاذ
 *   periods  : مجموع الساعات الأسبوعية
 *   pattern  : نمط التقسيم مثل [2,2,1]
 *   morning  : null = حسب المادة، true = صباحًا فقط، false = حرة
 *   crossBreak: السماح بعبور الاستراحة القصيرة (تلقائي للكتل ≥ 3 ساعات)
 */
(function () {
  const E = globalThis.EDT;
  const M = (E.model = {});

  M.blank = function (cycle) {
    const names = { primary: "ابتدائية", middle: "متوسطة", secondary: "ثانوية" };
    return {
      school: { name: names[cycle], cycle, wilaya: "الجزائر", commune: "", year: "2026/2027", director: "", counselor: "", phone: "", thursdayMorningOnly: false, amazigh: false },
      subjects: [], classes: [], teachers: [], assignments: [], placements: [], seed: 1, genKey: "",
    };
  };

  /* ---------- أنماط التقسيم ---------- */
  M.defaultPattern = function (n, double, cycle) {
    n = Math.max(0, Math.round(n));
    if (n <= 0) return [];
    if (cycle === "primary") {
      if (!double) return Array(n).fill(1);
      return Array(Math.floor(n / 2)).fill(2).concat(n % 2 ? [1] : []);
    }
    if (n === 1) return [1];
    if (n === 2) return double ? [2] : [1, 1];
    return Array(Math.floor(n / 2)).fill(2).concat(n % 2 ? [1] : []);
  };
  M.parsePattern = (str) => String(str || "").split(/[+،,\s]+/).map((x) => parseInt(x, 10)).filter((x) => x >= 1 && x <= 4);
  M.patternStr = (p) => (p || []).join("+");
  M.sum = (a) => a.reduce((x, y) => x + y, 0);

  /* ---------- المواد ---------- */
  M.ensureSubject = function (st, seed) {
    let sub = st.subjects.find((x) => x.name === seed.name);
    if (sub) return sub;
    sub = { id: E.subjectCode(seed.name), name: seed.name, short: seed.short, sci: E.isSciName(seed.name), prefer: seed.prefer || "any", double: !!seed.double };
    if (st.subjects.some((x) => x.id === sub.id)) sub.id = E.uid("s");
    st.subjects.push(sub);
    return sub;
  };
  M.subjectOf = (st, id) => st.subjects.find((x) => x.id === id);
  M.addCustomSubject = (st, name, short) => M.ensureSubject(st, { name: name.trim(), short: (short || name).trim().slice(0, 4), prefer: "any" });

  /* ---------- الأقسام ---------- */
  M.addClass = function (st, levelKey, section) {
    const lv = E.levelByKey(levelKey);
    if (!lv || lv.cycle !== st.school.cycle) return null;
    const name = lv.name(section);
    if (st.classes.some((c) => c.name === name)) return null;
    const id = E.uid("c");
    st.classes.push({ id, levelKey, label: lv.label, name });
    for (const seed of lv.subjects) {
      if (!seed.periods) continue;
      const sub = M.ensureSubject(st, seed);
      st.assignments.push(M.makeAssignment([id], [{ subjectId: sub.id, teacherId: null, label: "" }], seed.periods, M.defaultPattern(seed.periods, sub.double, st.school.cycle)));
    }
    if (st.school.amazigh) M.setAmazigh(st, true);
    return id;
  };
  M.makeAssignment = (classIds, parts, periods, pattern) => ({
    id: E.uid("a"), classIds, parts, periods, pattern: pattern && pattern.length ? pattern : [periods], morning: null, crossBreak: false,
  });
  M.removeClass = function (st, id) {
    st.classes = st.classes.filter((c) => c.id !== id);
    for (const a of st.assignments) a.classIds = a.classIds.filter((x) => x !== id);
    st.assignments = st.assignments.filter((a) => a.classIds.length);
    M.reconcile(st);
  };
  M.className = (st, id) => (st.classes.find((c) => c.id === id) || {}).name || "؟";

  M.setAmazigh = function (st, on) {
    st.school.amazigh = on;
    const sub = M.ensureSubject(st, { name: E.AMAZIGH_NAME, short: "أم", prefer: "any" });
    if (!on) {
      st.assignments = st.assignments.filter((a) => !(a.parts.length === 1 && a.parts[0].subjectId === sub.id));
      M.reconcile(st);
      return;
    }
    const n = E.amazighPeriods(st.school.cycle);
    for (const c of st.classes) {
      if (st.assignments.some((a) => a.classIds.includes(c.id) && a.parts.some((p) => p.subjectId === sub.id))) continue;
      st.assignments.push(M.makeAssignment([c.id], [{ subjectId: sub.id, teacherId: null, label: "" }], n, M.defaultPattern(n, false, st.school.cycle)));
    }
  };

  /* ---------- الأساتذة ---------- */
  M.addTeacher = function (st, name, subjectIds, maxPeriods) {
    const t = { id: E.uid("t"), name: name.trim(), subjectIds: subjectIds || [], maxPeriods: maxPeriods || E.quotaFor(st.school.cycle), unavailable: [] };
    st.teachers.push(t);
    return t;
  };
  M.removeTeacher = function (st, id) {
    st.teachers = st.teachers.filter((t) => t.id !== id);
    for (const a of st.assignments) for (const p of a.parts) if (p.teacherId === id) p.teacherId = null;
    M.reconcile(st);
  };
  M.teacherName = (st, id) => (st.teachers.find((t) => t.id === id) || {}).name || "—";
  M.teacherLoad = (st, id) =>
    st.assignments.reduce((s, a) => s + (a.parts.some((p) => p.teacherId === id) ? a.periods : 0), 0);

  /* ---------- الدمج والتخصصات ---------- */
  /* classIds: الأقسام المدمجة. commonIds: مواد مشتركة تصبح إسنادًا واحدًا.
   * specId + groups: مادة تتفرع إلى أفواج متزامنة (هندسة مدنية / كهربائية ...) */
  M.mergeClasses = function (st, { classIds, commonIds = [], specId = null, groups = [] }) {
    const take = (subId) => {
      const found = st.assignments.filter((a) => a.parts.length === 1 && a.parts[0].subjectId === subId && a.classIds.length === 1 && classIds.includes(a.classIds[0]));
      st.assignments = st.assignments.filter((a) => !found.includes(a));
      return found[0] || null;
    };
    for (const subId of commonIds) {
      const first = take(subId);
      if (!first) continue;
      const m = M.makeAssignment(classIds.slice(), [{ subjectId: subId, teacherId: first.parts[0].teacherId, label: "" }], first.periods, first.pattern.slice());
      m.morning = first.morning;
      st.assignments.push(m);
    }
    if (specId && groups.length) {
      const first = take(specId);
      const periods = first ? first.periods : 6;
      const sub = M.subjectOf(st, specId);
      st.assignments.push(M.makeAssignment(classIds.slice(), groups.map((g) => ({ subjectId: specId, teacherId: null, label: g })), periods, first ? first.pattern.slice() : M.defaultPattern(periods, sub && sub.double, st.school.cycle)));
    }
    M.reconcile(st);
  };

  /* ---------- الكتل (ما يُسلَّم للمُجدوِل) ---------- */
  M.toBlocks = function (st) {
    const grid = E.gridFor(st.school.cycle);
    const classIdSet = new Set(st.classes.map((c) => c.id));
    const teacherIdSet = new Set(st.teachers.map((t) => t.id));
    const blocks = [], skipped = [];
    for (const a of st.assignments) {
      const classIds = a.classIds.filter((x) => classIdSet.has(x));
      if (!classIds.length || !a.periods) continue;
      if (a.parts.some((p) => !p.teacherId || !teacherIdSet.has(p.teacherId))) { skipped.push({ aid: a.id, reason: "no_teacher" }); continue; }
      let pattern = a.pattern && M.sum(a.pattern) === a.periods ? a.pattern : M.defaultPattern(a.periods, false, st.school.cycle);
      const subs = a.parts.map((p) => M.subjectOf(st, p.subjectId)).filter(Boolean);
      const morning = a.morning === true || (a.morning == null && subs.some((x) => x.sci));
      const prefs = new Set(subs.map((x) => x.prefer));
      const prefer = prefs.size === 1 ? [...prefs][0] : "any";
      const teacherIds = [...new Set(a.parts.map((p) => p.teacherId))];
      const res = classIds.map((c) => "c:" + c).concat(teacherIds.map((t) => "t:" + t));
      pattern.forEach((len, i) => {
        const cross = len >= 3 || a.crossBreak ? [grid.shortBreak] : [];
        blocks.push({ id: `${a.id}:${i}`, aid: a.id, length: len, classIds, teacherIds, res, morning, prefer, cross });
      });
    }
    return { blocks, skipped };
  };
  M.unavailableSet = (st) => {
    const set = new Set();
    for (const t of st.teachers) for (const k of t.unavailable) { const [d, p] = k.split("-"); set.add(`t:${t.id}|${d}|${p}`); }
    return set;
  };
  M.solveInput = function (st, seed) {
    const grid = E.gridFor(st.school.cycle);
    const { blocks } = M.toBlocks(st);
    return { seed, days: E.DAY_COUNT, periodCount: grid.periods.length, barriers: grid.barriers, afternoonStart: grid.afternoonStart, thursdayMorningOnly: st.school.thursdayMorningOnly, unavailable: M.unavailableSet(st), blocks };
  };
  M.fingerprint = (st) =>
    JSON.stringify([st.school.cycle, st.school.thursdayMorningOnly, st.assignments.map((a) => [a.id, a.classIds, a.parts.map((p) => [p.subjectId, p.teacherId]), a.periods, a.pattern, a.morning, a.crossBreak]), st.teachers.map((t) => [t.id, t.unavailable.slice().sort()]), st.subjects.map((s) => [s.id, s.sci])]);

  /* إسقاط الحصص الموضوعة التي لم تعد صالحة بعد تعديل البيانات */
  M.reconcile = function (st) {
    const { blocks } = M.toBlocks(st);
    const byId = new Map(blocks.map((b) => [b.id, b]));
    const seen = new Set();
    st.placements = st.placements.filter((p) => {
      const b = byId.get(p.id);
      if (!b || b.length !== p.length || seen.has(p.id)) return false;
      seen.add(p.id);
      return true;
    });
  };
  M.unplacedBlocks = function (st) {
    const { blocks } = M.toBlocks(st);
    const placed = new Set(st.placements.map((p) => p.id));
    return blocks.filter((b) => !placed.has(b.id));
  };

  /* ---------- الفحوص قبل/بعد التوليد ---------- */
  M.diagnostics = function (st) {
    const out = [];
    const grid = E.gridFor(st.school.cycle);
    const cap = E.slotCapacity(grid, st.school.thursdayMorningOnly);
    const morningCap = grid.afternoonStart * E.DAY_COUNT;
    if (!st.classes.length) { out.push({ level: "error", text: "لا توجد أقسام. أضف قسمًا من تبويب «الأقسام»." }); return out; }
    const noTeacher = st.assignments.filter((a) => a.parts.some((p) => !p.teacherId));
    if (noTeacher.length) out.push({ level: "error", text: `${noTeacher.length} إسناد بلا أستاذ — لن يُوضع في الجدول. أكمله من تبويب «الإسناد».` });
    for (const a of st.assignments) {
      if (a.pattern && M.sum(a.pattern) !== a.periods) {
        const s = M.subjectOf(st, a.parts[0].subjectId);
        out.push({ level: "warn", text: `نمط التقسيم (${M.patternStr(a.pattern)}) لا يساوي ${a.periods} ساعة في «${s ? s.name : "؟"}» — سيُستعمل تقسيم تلقائي.` });
      }
    }
    for (const t of st.teachers) {
      const load = M.teacherLoad(st, t.id);
      if (load > t.maxPeriods) out.push({ level: "warn", text: `${t.name}: ${load} ساعة أكثر من النصاب (${t.maxPeriods}).` });
      const free = grid.periods.length * E.DAY_COUNT - t.unavailable.length;
      if (load > free) out.push({ level: "error", text: `${t.name}: ${load} ساعة لكن لديه ${free} فترة متاحة فقط.` });
    }
    for (const c of st.classes) {
      const mine = st.assignments.filter((a) => a.classIds.includes(c.id));
      const total = M.sum(mine.map((a) => a.periods));
      if (total > cap) out.push({ level: "error", text: `${c.name}: ${total} ساعة أكثر من سعة الأسبوع (${cap}).` });
      const mornHours = M.sum(mine.filter((a) => M.toBlocks({ ...st, assignments: [a] }).blocks.some((b) => b.morning)).map((a) => a.periods));
      if (mornHours > morningCap) out.push({ level: "error", text: `${c.name}: ${mornHours} ساعة علمية صباحية أكثر من سعة الصباح (${morningCap}).` });
      else if (mornHours > morningCap - 2) out.push({ level: "warn", text: `${c.name}: الصباح شبه ممتلئ (${mornHours}/${morningCap}) — قد تبقى ثغرات.` });
    }
    /* جدوى كل كتلة على حدة (دون النظر إلى غيرها) */
    const inp = M.solveInput(st, 1);
    let bad = 0;
    for (const b of inp.blocks) {
      let ok = false;
      for (let d = 0; d < inp.days && !ok; d++)
        for (let p = 0; p + b.length <= inp.periodCount && !ok; p++) {
          if (E.crosses(p, b.length, inp.barriers, b.cross)) continue;
          if (b.morning && p + b.length - 1 >= inp.afternoonStart) continue;
          if (inp.thursdayMorningOnly && d === 4 && p + b.length - 1 >= inp.afternoonStart) continue;
          let free = true;
          for (const r of b.res) for (let k = 0; k < b.length; k++) if (inp.unavailable.has(`${r}|${d}|${p + k}`)) free = false;
          if (free) ok = true;
        }
      if (!ok) bad++;
    }
    if (bad) out.push({ level: "error", text: `${bad} حصة (كتلة) لا يوجد لها أي موضع ممكن بسبب القيود (استراحات/صباح/عدم توفر الأساتذة).` });
    return out;
  };

  /* ---------- بناء جدول للعرض/التصدير ---------- */
  M.colorOf = (st, subId) => E.PALETTE[Math.max(0, st.subjects.findIndex((s) => s.id === subId)) % E.PALETTE.length];
  M.buildGrid = function (st, kind, id) {
    const grid = E.gridFor(st.school.cycle);
    const { blocks } = M.toBlocks(st);
    const byId = new Map(blocks.map((b) => [b.id, b]));
    const asg = new Map(st.assignments.map((a) => [a.id, a]));
    const rows = [], rowOf = {};
    grid.periods.forEach((p) => {
      rowOf[p.index] = rows.length;
      rows.push({ kind: "period", index: p.index, label: p.label, time: `${p.start} - ${p.end}` });
      if (grid.breaks[p.index]) rows.push({ kind: "break", label: grid.breaks[p.index] });
    });
    const cells = rows.map((r) => E.DAYS.map(() => (r.kind === "break" ? { brk: true } : null)));
    let hours = 0;
    for (const pl of st.placements) {
      const b = byId.get(pl.id), a = asg.get(pl.aid);
      if (!b || !a) continue;
      const mine = kind === "class" ? b.classIds.includes(id) : b.teacherIds.includes(id);
      if (!mine) continue;
      hours += b.length;
      const lines = [];
      const parts = kind === "teacher" ? a.parts.filter((p) => p.teacherId === id) : a.parts;
      for (const p of parts) {
        const sub = M.subjectOf(st, p.subjectId);
        const title = p.label ? (a.parts.length > 1 || (sub && p.label !== sub.name) ? p.label : sub.name) : sub ? sub.name : "؟";
        if (kind === "class") lines.push(a.parts.length > 1 ? `${title}: ${M.teacherName(st, p.teacherId)}` : title, ...(a.parts.length > 1 ? [] : [M.teacherName(st, p.teacherId)]));
        else lines.push(title);
      }
      if (kind === "teacher") lines.push(b.classIds.map((c) => M.className(st, c)).join(" + "));
      else if (b.classIds.length > 1) lines.push("(مدمج: " + b.classIds.filter((c) => c !== id).map((c) => M.className(st, c)).join("، ") + ")");
      const r0 = rowOf[pl.period], r1 = rowOf[pl.period + pl.length - 1];
      cells[r0][pl.day] = { id: pl.id, rowspan: r1 - r0 + 1, lines, color: M.colorOf(st, a.parts[0].subjectId), length: pl.length };
      for (let r = r0 + 1; r <= r1; r++) cells[r][pl.day] = { skip: true };
    }
    const sch = st.school;
    const title = kind === "class" ? `جدول القسم: ${M.className(st, id)}` : `جدول الأستاذ: ${M.teacherName(st, id)}`;
    const subtitle = [sch.name, sch.year, sch.commune && `${sch.commune} - ${sch.wilaya}`].filter(Boolean).join(" · ");
    return { title, subtitle, days: E.DAYS, rows, cells, hours, kind, id };
  };
})();
