/* النواة: فضاء الأسماء والأدوات العامة */
(function () {
  const E = (globalThis.EDT = globalThis.EDT || {});
  E.uid = (p = "x") => p + "-" + Math.random().toString(36).slice(2, 9);
  E.esc = (s) =>
    String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  E.clone = (o) => JSON.parse(JSON.stringify(o));
  E.DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"];
  E.DAY_COUNT = 5;
  E.CYCLE_LABEL = { primary: "التعليم الابتدائي", middle: "التعليم المتوسط", secondary: "التعليم الثانوي" };
  E.quotaFor = (cycle) => (cycle === "primary" ? 24 : cycle === "middle" ? 20 : 16);
  E.PALETTE = ["#dcebdd", "#f4dedb", "#f1ead0", "#d9e6f2", "#ecdcf0", "#f3e3cf", "#d8eeee", "#e8e8d4", "#f0d9e4", "#dde3f5"];
})();
