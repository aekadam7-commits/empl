/* تشغيل: node tests/run.mjs */
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "www", "js");
const order = ["00-core.js", "10-grid.js", "20-presets.js", "30-model.js", "35-demos.js", "40-solver.js"];
for (const f of order) vm.runInThisContext(fs.readFileSync(path.join(root, f), "utf8"), { filename: f });
const E = globalThis.EDT, M = E.model;

let fails = 0;
const ok = (cond, msg) => { if (!cond) { fails++; console.log("  ✗", msg); } else console.log("  ✓", msg); };

function run(name, st) {
  console.log("\n▶", name);
  const inp = M.solveInput(st, 1);
  const r = E.solver.solve(inp);
  const errs = E.solver.audit(inp, r.placements);
  console.log(`   كتل=${inp.blocks.length} موضوعة=${r.placements.length} غير موضوعة=${r.unplaced.length} ثغرات أقسام=${r.classGaps} أساتذة=${r.teacherGaps} زمن=${r.ms}ms`);
  ok(errs.length === 0, "لا تعارضات ولا خرق قيود: " + errs.slice(0, 3).join(" | "));
  ok(r.unplaced.length === 0, "كل الحصص موضوعة");
  return { inp, r };
}

/* 1) الثانوي التقني: دمج + تخصصات + تطبيقات + صباح للمواد العلمية */
{
  const st = M.blank("secondary"); Object.assign(st, E.demos.secondaryTech());
  const { inp, r } = run("ثانوي تقني (دمج/تخصصات/تطبيقات)", st);
  const byId = new Map(inp.blocks.map((b) => [b.id, b]));
  const morningOnly = r.placements.filter((p) => byId.get(p.id).morning);
  ok(morningOnly.length > 0 && morningOnly.every((p) => p.period + p.length - 1 < 4), `المواد العلمية كلها صباحًا (${morningOnly.length} كتلة)`);
  const tp = st.assignments.find((a) => a.parts.length === 2);
  const spec = st.assignments.find((a) => a.parts.length === 3);
  const specBlocks = r.placements.filter((p) => p.aid === spec.id);
  ok(specBlocks.length === spec.pattern.length, "حصص التخصص: كتلة لكل جزء من النمط " + M.patternStr(spec.pattern));
  const b = byId.get(specBlocks[0].id);
  ok(b.teacherIds.length === 3 && b.classIds.length === 2, "حصة التخصص تحجز 3 أساتذة وقسمين مدمجين معًا");
  const math = st.assignments.find((a) => a.classIds.length === 2 && a.parts[0].subjectId === "math");
  ok(M.patternStr(math.pattern) === "2+2+2", "رياضيات 6 ساعات → " + M.patternStr(math.pattern));
  const tpBlocks = r.placements.filter((p) => p.aid === tp.id);
  ok(tpBlocks.length === 1 && tpBlocks[0].length === 2, "التطبيقات: حصة واحدة متتالية ساعتان");
  /* حصة 5 ساعات = 2+2+1 */
  const st2 = M.blank("secondary"); M.addClass(st2, "2exp", 1);
  const m = st2.assignments.find((a) => a.parts[0].subjectId === "math");
  ok(M.patternStr(m.pattern) === "2+2+1", "رياضيات 5 ساعات → 2+2+1");
  const pe = st2.assignments.find((a) => a.parts[0].subjectId === "pe");
  ok(M.patternStr(pe.pattern) === "2", "الرياضة ساعتان → حصة واحدة متتالية (2)");
}

/* 2) تطبيقات أربع ساعات صباحًا تعبر الاستراحة القصيرة فقط */
{
  const st = M.blank("secondary");
  M.addClass(st, "1sct", 1);
  const a = st.assignments.find((x) => x.parts[0].subjectId === "phys");
  const t1 = M.addTeacher(st, "أ", ["nat"]), t2 = M.addTeacher(st, "ب", ["phys"]);
  a.parts = [{ subjectId: "nat", teacherId: t1.id, label: "" }, { subjectId: "phys", teacherId: t2.id, label: "" }];
  a.periods = 4; a.pattern = [4];
  st.assignments = st.assignments.filter((x) => x === a);
  const { inp, r } = run("تطبيقات 4 ساعات", st);
  ok(r.placements.length === 1 && r.placements[0].length === 4 && r.placements[0].period === 0, "الكتلة 4 ساعات تبدأ 08:00 وتعبر الاستراحة القصيرة");
  // أستاذ غير متاح في الصباح كله → يجب ألا توضع
  t1.unavailable = [0, 1, 2, 3, 4].flatMap((d) => [0, 1, 2, 3].map((p) => `${d}-${p}`));
  const inp2 = M.solveInput(st, 1);
  ok(E.solver.solve(inp2).unplaced.length === 1, "لا تُوضع الحصة الصباحية إن كان الأستاذ غير متاح صباحًا");
}

/* 3) متوسط وابتدائي */
run("متوسط", E.demos.middle());
run("ابتدائي", E.demos.primary());

/* 4) اختبار ضغط: 20 قسمًا */
{
  const st = M.blank("middle");
  for (const lv of ["1m", "2m", "3m", "4m"]) for (let s = 1; s <= 5; s++) M.addClass(st, lv, s);
  const by = new Map();
  for (const a of st.assignments) { const k = a.parts[0].subjectId; if (!by.has(k)) by.set(k, []); by.get(k).push(a); }
  for (const [sid, list] of by) for (let i = 0; i < list.length; i += 4) { const t = M.addTeacher(st, `${sid}${i}`, [sid], 30); for (const a of list.slice(i, i + 4)) a.parts[0].teacherId = t.id; }
  run("ضغط: 20 قسمًا متوسط", st);
}

/* 5) الفحوص */
{
  const st = E.demos.middle();
  ok(M.diagnostics(st).every((d) => d.level !== "error"), "نموذج المتوسط بلا أخطاء فحص");
  const bad = M.blank("secondary"); M.addClass(bad, "2exp", 1);
  ok(M.diagnostics(bad).some((d) => d.level === "error"), "إسناد بلا أستاذ يظهر كخطأ");
}

console.log(fails ? `\n❌ ${fails} إخفاق` : "\n✅ كل الاختبارات نجحت");
process.exit(fails ? 1 : 0);
