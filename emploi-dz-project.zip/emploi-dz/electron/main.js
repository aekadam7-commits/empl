const { app, BrowserWindow, Menu } = require("electron");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 860, minWidth: 420, minHeight: 600,
    title: "استعمال الزمن", backgroundColor: "#f3efe7", autoHideMenuBar: true, show: false,
    icon: path.join(__dirname, "..", "build", "icon.png"),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false },
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, "..", "www", "index.html"));
  win.once("ready-to-show", () => win.show());
  /* إن فشل التحميل لأي سبب نعرض رسالة بدل شاشة بيضاء */
  win.webContents.on("did-fail-load", (_e, code, desc) => {
    win.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(`<body dir="rtl" style="font-family:Tahoma;padding:40px"><h2>تعذّر تحميل التطبيق</h2><p>${desc} (${code})</p></body>`));
  });
}
app.whenReady().then(createWindow);
app.on("window-all-closed", () => app.quit());
